module google.golang.org/genproto/googleapis/api

go 1.25.0

require (
	google.golang.org/genproto/googleapis/rpc v0.0.0-20260729162451-8efbd57d26e0
	google.golang.org/grpc v1.79.3
	google.golang.org/protobuf v1.36.11
)

require (
	golang.org/x/net v0.55.0 // indirect
	golang.org/x/sys v0.45.0 // indirect
	golang.org/x/text v0.37.0 // indirect
)
