// Copyright 2022 The age Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//go:build ignore
// +build ignore

package main

import "c2sp.org/CCTV/age/internal/testkit"

func main() {
	f := testkit.NewTestFile()
	f.VersionLine("v1")
	f.HybridRecordIdentity(testkit.TestHybridIdentity)
	share := make([]byte, 32)
	f.HybridStanza(share, f.Rand(32), testkit.TestHybridIdentity)
	f.HMAC()
	f.Payload("age")
	f.ExpectHeaderFailure()
	f.Comment("the X25519 part of enc is the identity point, so the shared secret" +
		"is the disallowed all-zero value")
	f.Generate()
}
