module github.com/xuri/excelize/v2

go 1.25.0

require (
	github.com/richardlehane/mscfb v1.0.8
	github.com/stretchr/testify v1.11.1
	github.com/tiendc/go-deepcopy v1.7.2
	github.com/xuri/efp v0.0.1
	github.com/xuri/nfp v0.0.2-0.20250530014748-2ddeb826f9a9
	golang.org/x/crypto v0.55.0
	golang.org/x/image v0.44.0
	golang.org/x/net v0.58.0
	golang.org/x/text v0.41.0
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/richardlehane/msoleps v1.0.6 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
