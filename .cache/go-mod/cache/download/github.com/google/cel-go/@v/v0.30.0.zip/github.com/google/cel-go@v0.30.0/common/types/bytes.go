// Copyright 2018 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package types

import (
	"bytes"
	"encoding/base64"
	"fmt"
	"reflect"
	"strings"
	"unicode/utf8"

	"github.com/google/cel-go/common/types/ref"

	anypb "google.golang.org/protobuf/types/known/anypb"
	structpb "google.golang.org/protobuf/types/known/structpb"
	wrapperspb "google.golang.org/protobuf/types/known/wrapperspb"
)

// Bytes type that implements ref.Val and supports add, compare, and size
// operations.
type Bytes []byte

var (
	// byteWrapperType golang reflected type for protobuf bytes wrapper type.
	byteWrapperType = reflect.TypeOf(&wrapperspb.BytesValue{})
)

// Add implements traits.Adder interface method by concatenating byte sequences.
func (b Bytes) Add(other ref.Val) ref.Val {
	otherBytes, ok := other.(Bytes)
	if !ok {
		return ValOrErr(other, "no such overload")
	}
	sum := make([]byte, 0, len(b)+len(otherBytes))
	sum = append(sum, b...)
	sum = append(sum, otherBytes...)
	return Bytes(sum)
}

// Compare implements traits.Comparer interface method by lexicographic ordering.
func (b Bytes) Compare(other ref.Val) ref.Val {
	otherBytes, ok := other.(Bytes)
	if !ok {
		return ValOrErr(other, "no such overload")
	}
	return Int(bytes.Compare(b, otherBytes))
}

// ConvertToNative implements the ref.Val interface method.
func (b Bytes) ConvertToNative(typeDesc reflect.Type) (any, error) {
	switch typeDesc.Kind() {
	case reflect.Array:
		if len(b) != typeDesc.Len() {
			return nil, fmt.Errorf("[%d]byte not assignable to [%d]byte array", len(b), typeDesc.Len())
		}
		refArrPtr := reflect.New(reflect.ArrayOf(len(b), typeDesc.Elem()))
		refArr := refArrPtr.Elem()
		for i, byt := range b {
			refArr.Index(i).Set(reflect.ValueOf(byt).Convert(typeDesc.Elem()))
		}
		return refArr.Interface(), nil
	case reflect.Slice:
		return reflect.ValueOf(b).Convert(typeDesc).Interface(), nil
	case reflect.Ptr:
		switch typeDesc {
		case anyValueType:
			// Primitives must be wrapped before being set on an Any field.
			return anypb.New(wrapperspb.Bytes([]byte(b)))
		case byteWrapperType:
			// Convert the bytes to a wrapperspb.BytesValue.
			return wrapperspb.Bytes([]byte(b)), nil
		case JSONValueType:
			// CEL follows the proto3 to JSON conversion by encoding bytes to a string via base64.
			// The encoding below matches the golang 'encoding/json' behavior during marshaling,
			// which uses base64.StdEncoding.
			str := base64.StdEncoding.EncodeToString([]byte(b))
			return structpb.NewStringValue(str), nil
		}
	case reflect.Interface:
		bv := b.Value()
		if reflect.TypeOf(bv).Implements(typeDesc) {
			return bv, nil
		}
		if reflect.TypeOf(b).Implements(typeDesc) {
			return b, nil
		}
	}
	return nil, fmt.Errorf("type conversion error from Bytes to '%v'", typeDesc)
}

// ConvertToType implements the ref.Val interface method.
func (b Bytes) ConvertToType(typeVal ref.Type) ref.Val {
	switch typeVal {
	case StringType:
		if !utf8.Valid(b) {
			return NewErr("invalid UTF-8 in bytes, cannot convert to string")
		}
		return String(b)
	case BytesType:
		return b
	case TypeType:
		return BytesType
	}
	return NewErr("type conversion error from '%s' to '%s'", BytesType, typeVal)
}

// Equal implements the ref.Val interface method.
func (b Bytes) Equal(other ref.Val) ref.Val {
	otherBytes, ok := other.(Bytes)
	return Bool(ok && bytes.Equal(b, otherBytes))
}

// IsZeroValue returns true if the byte array is empty.
func (b Bytes) IsZeroValue() bool {
	return len(b) == 0
}

// Size implements the traits.Sizer interface method.
func (b Bytes) Size() ref.Val {
	return Int(len(b))
}

// Type implements the ref.Val interface method.
func (b Bytes) Type() ref.Type {
	return BytesType
}

// Value implements the ref.Val interface method.
func (b Bytes) Value() any {
	return []byte(b)
}

func (b Bytes) format(sb *strings.Builder) {
	fmt.Fprintf(sb, "b\"%s\"", bytesToOctets([]byte(b)))
}

// bytesToOctets converts byte sequences to a string using a three digit octal encoded value
// per byte.
func bytesToOctets(byteVal []byte) string {
	var b strings.Builder
	for _, c := range byteVal {
		fmt.Fprintf(&b, "\\%03o", c)
	}
	return b.String()
}
