package actions

import (
	"context"
	"errors"
	"fmt"
	"sort"
	"sync"
	"time"

	config "github.com/conductorone/baton-sdk/pb/c1/config/v1"
	v2 "github.com/conductorone/baton-sdk/pb/c1/connector/v2"
	"github.com/conductorone/baton-sdk/pkg/annotations"
	"github.com/conductorone/baton-sdk/pkg/crypto"
	"github.com/grpc-ecosystem/go-grpc-middleware/logging/zap/ctxzap"
	"github.com/segmentio/ksuid"
	"go.opentelemetry.io/otel/trace"
	"go.uber.org/zap"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/anypb"
	"google.golang.org/protobuf/types/known/structpb"
)

type ActionHandler func(ctx context.Context, args *structpb.Struct) (*structpb.Struct, annotations.Annotations, error)

// ActionHandlerWithSecrets returns public values separately from plaintext
// secret values. The action manager encrypts PlaintextData before publishing
// the result or retaining it for a later status request.
type ActionHandlerWithSecrets func(
	ctx context.Context,
	args *structpb.Struct,
) (*structpb.Struct, []*v2.PlaintextData, annotations.Annotations, error)

type actionHandlerResult struct {
	response      *structpb.Struct
	plaintextData []*v2.PlaintextData
	annotations   annotations.Annotations
	err           error
}

type registeredActionHandler struct {
	invoke                    func(context.Context, *structpb.Struct) actionHandlerResult
	secretReturnNames         map[string]struct{}
	requiredSecretReturnNames []string
}

type actionEncryptFunc func(context.Context, *crypto.EncryptionManager, *v2.PlaintextData) ([]*v2.EncryptedData, error)

// IsInFlight reports whether the status describes an action
// still executing: PENDING or RUNNING.
func IsInFlight(s v2.BatonActionStatus) bool {
	return s == v2.BatonActionStatus_BATON_ACTION_STATUS_PENDING || s == v2.BatonActionStatus_BATON_ACTION_STATUS_RUNNING
}

// IsSettled reports whether the status is terminal: COMPLETE or
// FAILED. It is the single gate deciding which statuses are final; a new
// terminal enum value must be added here to be treated as settled anywhere.
func IsSettled(s v2.BatonActionStatus) bool {
	return s == v2.BatonActionStatus_BATON_ACTION_STATUS_COMPLETE || s == v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED
}

type OutstandingAction struct {
	Id            string
	Name          string
	Status        v2.BatonActionStatus
	Rv            *structpb.Struct
	EncryptedData []*v2.EncryptedData
	Annos         annotations.Annotations
	Err           error
	StartedAt     time.Time
	sync.Mutex

	// cancelled marks a FAILED status that came from request cancellation
	// rather than from the handler; the handler's late outcome replaces it.
	cancelled bool
}

func NewOutstandingAction(id, name string) *OutstandingAction {
	return &OutstandingAction{
		Id:        id,
		Name:      name,
		Status:    v2.BatonActionStatus_BATON_ACTION_STATUS_PENDING,
		StartedAt: time.Now(),
	}
}

func (oa *OutstandingAction) SetStatus(ctx context.Context, status v2.BatonActionStatus) {
	oa.Lock()
	defer oa.Unlock()
	oa.setStatusLocked(ctx, status)
}

// setStatusLocked applies a lifecycle transition and reports whether it was
// accepted. Terminal statuses are final and RUNNING is only reachable from
// PENDING; rejected transitions are dropped. These fire in normal operation
// (a handler finishing after its request was cancelled), hence debug level.
// It requires oa's mutex to be held.
func (oa *OutstandingAction) setStatusLocked(ctx context.Context, status v2.BatonActionStatus) bool {
	if IsSettled(oa.Status) {
		ctxzap.Extract(ctx).Debug("dropping status transition on terminal action",
			zap.String("action_id", oa.Id),
			zap.String("action_name", oa.Name),
			zap.String("status", oa.Status.String()),
			zap.String("requested_status", status.String()))
		return false
	}
	if status == v2.BatonActionStatus_BATON_ACTION_STATUS_RUNNING && oa.Status != v2.BatonActionStatus_BATON_ACTION_STATUS_PENDING {
		ctxzap.Extract(ctx).Debug("dropping running transition on non-pending action",
			zap.String("action_id", oa.Id),
			zap.String("action_name", oa.Name),
			zap.String("status", oa.Status.String()))
		return false
	}

	oa.Status = status
	return true
}

// setErrorLocked requires oa's mutex to be held.
func (oa *OutstandingAction) setErrorLocked(err error) {
	// Rebuild rather than mutate: a concurrent caller may hold the previously
	// published struct from a result() snapshot and be marshaling it.
	fields := make(map[string]*structpb.Value, len(oa.Rv.GetFields())+1)
	for k, v := range oa.Rv.GetFields() {
		fields[k] = v
	}
	fields["error"] = &structpb.Value{
		Kind: &structpb.Value_StringValue{
			StringValue: err.Error(),
		},
	}
	oa.Rv = &structpb.Struct{Fields: fields}
	oa.Err = err
}

// SetError records the error and marks the action failed in one critical
// section, so no snapshot can observe the error with a non-terminal status.
// A FAILED action may refresh its error payload, but a COMPLETE action stays
// complete. This is a real handler failure, so it clears any provisional
// cancellation mark.
func (oa *OutstandingAction) SetError(ctx context.Context, err error) {
	oa.Lock()
	defer oa.Unlock()
	if oa.Status == v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED {
		oa.EncryptedData = nil
		oa.setErrorLocked(err)
		oa.cancelled = false
		return
	}
	if oa.setStatusLocked(ctx, v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED) {
		oa.EncryptedData = nil
		oa.setErrorLocked(err)
	}
}

// setCancelled records a cancellation as a provisional failure: unlike other
// terminal states, the handler's own late outcome replaces it, since the
// action's side effects can still complete after the request goes away.
func (oa *OutstandingAction) setCancelled(ctx context.Context, err error) {
	oa.Lock()
	defer oa.Unlock()
	if oa.setStatusLocked(ctx, v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED) {
		oa.setErrorLocked(err)
		oa.cancelled = true
	}
}

// isProvisional reports whether the action's FAILED status is a provisional
// cancellation mark that the handler's late outcome may still replace.
func (oa *OutstandingAction) isProvisional() bool {
	oa.Lock()
	defer oa.Unlock()
	return oa.cancelled
}

// evictable reports whether the action has reached a state cleanup may
// remove: terminal, and not a provisional cancellation whose record can
// still improve.
func (oa *OutstandingAction) evictable() bool {
	oa.Lock()
	defer oa.Unlock()
	if oa.cancelled {
		return false
	}
	return IsSettled(oa.Status)
}

// Result returns the action's identity and current outcome. The snapshot is
// internally consistent; the returned message and annotations are owned by
// the action and must not be modified.
func (oa *OutstandingAction) Result() (string, v2.BatonActionStatus, *structpb.Struct, annotations.Annotations) {
	return oa.result()
}

// result is the unexported form of Result.
func (oa *OutstandingAction) result() (string, v2.BatonActionStatus, *structpb.Struct, annotations.Annotations) {
	id, status, response, _, annos := oa.resultWithEncryptedData()
	return id, status, response, annos
}

// ResultWithEncryptedData returns the action's public and encrypted outcomes.
// The returned messages are owned by the action and must not be modified.
func (oa *OutstandingAction) ResultWithEncryptedData() (string, v2.BatonActionStatus, *structpb.Struct, []*v2.EncryptedData, annotations.Annotations) {
	return oa.resultWithEncryptedData()
}

func (oa *OutstandingAction) resultWithEncryptedData() (string, v2.BatonActionStatus, *structpb.Struct, []*v2.EncryptedData, annotations.Annotations) {
	oa.Lock()
	defer oa.Unlock()
	return oa.Id, oa.Status, oa.Rv, oa.EncryptedData, oa.Annos
}

// setOutcome publishes the handler's result and terminal status in one
// critical section, so no snapshot observes one without the other. The
// values are cloned at this publication seam: the handler owns what it
// returned and may keep mutating it. Terminal statuses are final, with one
// exception: a cancellation-FAILED status is provisional, and the handler's
// own outcome — success or failure — replaces it.
func (oa *OutstandingAction) setOutcome(ctx context.Context, rv *structpb.Struct, annos annotations.Annotations, err error) {
	oa.setOutcomeWithEncryptedData(ctx, rv, nil, annos, err)
}

func (oa *OutstandingAction) setOutcomeWithEncryptedData(
	ctx context.Context,
	rv *structpb.Struct,
	encryptedData []*v2.EncryptedData,
	annos annotations.Annotations,
	err error,
) {
	if rv != nil {
		rv = proto.Clone(rv).(*structpb.Struct)
	}
	if encryptedData != nil {
		encryptedDataCopy := make([]*v2.EncryptedData, len(encryptedData))
		for i, encrypted := range encryptedData {
			if encrypted != nil {
				encryptedDataCopy[i] = proto.Clone(encrypted).(*v2.EncryptedData)
			}
		}
		encryptedData = encryptedDataCopy
	}
	if annos != nil {
		annosCopy := make(annotations.Annotations, len(annos))
		for i, a := range annos {
			if a != nil {
				annosCopy[i] = proto.Clone(a).(*anypb.Any)
			}
		}
		annos = annosCopy
	}

	oa.Lock()
	defer oa.Unlock()

	if err != nil {
		if oa.Status == v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED || oa.setStatusLocked(ctx, v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED) {
			oa.Rv = rv
			oa.EncryptedData = nil
			oa.Annos = annos
			oa.setErrorLocked(err)
			oa.cancelled = false
		}
		return
	}

	if oa.cancelled {
		// Deliberate cross-terminal replacement: the cancellation was a
		// transport event, not the action's outcome.
		ctxzap.Extract(ctx).Debug("replacing provisional cancellation with handler outcome",
			zap.String("action_id", oa.Id),
			zap.String("action_name", oa.Name))
		oa.cancelled = false
		oa.Status = v2.BatonActionStatus_BATON_ACTION_STATUS_COMPLETE
		oa.Rv = rv
		oa.EncryptedData = encryptedData
		oa.Annos = annos
		oa.Err = nil
		return
	}

	if oa.setStatusLocked(ctx, v2.BatonActionStatus_BATON_ACTION_STATUS_COMPLETE) {
		oa.Rv = rv
		oa.EncryptedData = encryptedData
		oa.Annos = annos
	}
}

const (
	maxOldActions = 1000

	// defaultInlineWait bounds the invoke-time wait when the caller does not
	// request one.
	defaultInlineWait = 1 * time.Second

	// maxInlineWait caps the requested wait at the handler context budget:
	// holding the call open longer than a handler may run is never useful,
	// and a saturated Duration must not pin the request forever on the
	// deadline-less contexts service mode and the Lambda transport produce.
	maxInlineWait = 1 * time.Hour
)

// clampInlineWait bounds a requested inline wait: non-positive values take
// the server default and oversized values are capped at maxInlineWait. Not
// every transport enforces the wire validation rules, so this clamp is the
// only universal bound.
func clampInlineWait(inlineWait time.Duration) time.Duration {
	if inlineWait <= 0 {
		return defaultInlineWait
	}
	if inlineWait > maxInlineWait {
		return maxInlineWait
	}
	return inlineWait
}

// ActionRegistry provides methods for registering actions.
// Used by both GlobalActionProvider (global actions) and ResourceActionProvider (resource-scoped actions).
type ActionRegistry interface {
	// Register registers an action using the name from the schema.
	Register(ctx context.Context, schema *v2.BatonActionSchema, handler ActionHandler) error

	// Deprecated: Use Register instead.
	// RegisterAction registers an action.
	RegisterAction(ctx context.Context, name string, schema *v2.BatonActionSchema, handler ActionHandler) error
}

type actionRegistryWithSecrets interface {
	RegisterWithSecrets(ctx context.Context, schema *v2.BatonActionSchema, handler ActionHandlerWithSecrets) error
}

// RegisterWithSecrets registers an action whose handler can return plaintext
// secret values. The registry validates and encrypts those values before they
// are observable through InvokeAction or GetActionStatus.
func RegisterWithSecrets(
	ctx context.Context,
	registry ActionRegistry,
	schema *v2.BatonActionSchema,
	handler ActionHandlerWithSecrets,
) error {
	secretRegistry, ok := registry.(actionRegistryWithSecrets)
	if !ok {
		return errors.New("action registry does not support secret results")
	}
	return secretRegistry.RegisterWithSecrets(ctx, schema, handler)
}

// Deprecated: Use ActionRegistry instead.
// ResourceTypeActionRegistry is an alias for ActionRegistry for backwards compatibility.
type ResourceTypeActionRegistry = ActionRegistry

// ActionManager manages both global actions and resource-scoped actions.
type ActionManager struct {
	// Global actions (no resource type)
	schemas  map[string]*v2.BatonActionSchema // actionName -> schema
	handlers map[string]registeredActionHandler

	// Resource-scoped actions (keyed by resource type)
	resourceSchemas  map[string]map[string]*v2.BatonActionSchema // resourceTypeID -> actionName -> schema
	resourceHandlers map[string]map[string]registeredActionHandler

	// Outstanding actions (shared across global and resource-scoped)
	actions map[string]*OutstandingAction // actionID -> outstanding action

	encryptPlaintext actionEncryptFunc
	mu               sync.RWMutex
}

func NewActionManager(_ context.Context) *ActionManager {
	return &ActionManager{
		schemas:          make(map[string]*v2.BatonActionSchema),
		handlers:         make(map[string]registeredActionHandler),
		resourceSchemas:  make(map[string]map[string]*v2.BatonActionSchema),
		resourceHandlers: make(map[string]map[string]registeredActionHandler),
		actions:          make(map[string]*OutstandingAction),
		encryptPlaintext: func(ctx context.Context, manager *crypto.EncryptionManager, plaintext *v2.PlaintextData) ([]*v2.EncryptedData, error) {
			return manager.Encrypt(ctx, plaintext)
		},
	}
}

func (a *ActionManager) GetNewActionId() string {
	uid := ksuid.New()
	return uid.String()
}

func (a *ActionManager) GetNewAction(name string) *OutstandingAction {
	a.mu.Lock()
	defer a.mu.Unlock()
	actionId := a.GetNewActionId()
	oa := NewOutstandingAction(actionId, name)
	a.actions[actionId] = oa
	return oa
}

func (a *ActionManager) CleanupOldActions(ctx context.Context) {
	a.mu.Lock()
	defer a.mu.Unlock()

	if len(a.actions) < maxOldActions {
		return
	}

	l := ctxzap.Extract(ctx)
	l.Debug("cleaning up old actions")
	// Create a slice to hold the actions
	actionList := make([]*OutstandingAction, 0, len(a.actions))
	for _, action := range a.actions {
		actionList = append(actionList, action)
	}

	// Sort the actions by StartedAt time
	sort.Slice(actionList, func(i, j int) bool {
		return actionList[i].StartedAt.Before(actionList[j].StartedAt)
	})

	count := 0
	// Delete the oldest actions
	for i := 0; i < len(actionList)-maxOldActions; i++ {
		if actionList[i].evictable() {
			count++
			delete(a.actions, actionList[i].Id)
		}
	}
	l.Debug("cleaned up old actions", zap.Int("count", count))
}

func (a *ActionManager) registerActionSchema(_ context.Context, name string, schema *v2.BatonActionSchema) error {
	if name == "" {
		return errors.New("action name cannot be empty")
	}
	if schema == nil {
		return errors.New("action schema cannot be nil")
	}
	if _, ok := a.schemas[name]; ok {
		return fmt.Errorf("action schema %s already registered", name)
	}
	a.schemas[name] = schema
	return nil
}

// Register registers a global action using the name from the schema.
func (a *ActionManager) Register(ctx context.Context, schema *v2.BatonActionSchema, handler ActionHandler) error {
	if schema == nil {
		return errors.New("action schema cannot be nil")
	}
	return a.RegisterAction(ctx, schema.GetName(), schema, handler)
}

// Deprecated: Use Register instead.
// RegisterAction registers a global action (not scoped to a resource type).
func (a *ActionManager) RegisterAction(ctx context.Context, name string, schema *v2.BatonActionSchema, handler ActionHandler) error {
	if handler == nil {
		return errors.New("action handler cannot be nil")
	}
	if hasSecretReturnTypes(schema) {
		return errors.New("action schemas with secret return types must use RegisterWithSecrets")
	}
	return a.registerGlobalAction(ctx, name, schema, registeredActionHandler{
		invoke: func(ctx context.Context, args *structpb.Struct) actionHandlerResult {
			response, annos, err := handler(ctx, args)
			return actionHandlerResult{response: response, annotations: annos, err: err}
		},
	})
}

// RegisterWithSecrets registers a global action that returns plaintext secret
// values separately from its public response.
func (a *ActionManager) RegisterWithSecrets(ctx context.Context, schema *v2.BatonActionSchema, handler ActionHandlerWithSecrets) error {
	if schema == nil {
		return errors.New("action schema cannot be nil")
	}
	if handler == nil {
		return errors.New("action handler cannot be nil")
	}
	if !hasSecretReturnTypes(schema) {
		return errors.New("secret action handler requires at least one secret return type")
	}
	secretReturnNames, requiredSecretReturnNames, err := validateSecretReturnTypes(schema.GetReturnTypes())
	if err != nil {
		return err
	}
	return a.registerGlobalAction(ctx, schema.GetName(), schema, registeredActionHandler{
		invoke: func(ctx context.Context, args *structpb.Struct) actionHandlerResult {
			response, plaintextData, annos, err := handler(ctx, args)
			return actionHandlerResult{response: response, plaintextData: plaintextData, annotations: annos, err: err}
		},
		secretReturnNames:         secretReturnNames,
		requiredSecretReturnNames: requiredSecretReturnNames,
	})
}

func (a *ActionManager) registerGlobalAction(ctx context.Context, name string, schema *v2.BatonActionSchema, handler registeredActionHandler) error {
	a.mu.Lock()
	defer a.mu.Unlock()

	if handler.invoke == nil {
		return errors.New("action handler cannot be nil")
	}
	err := a.registerActionSchema(ctx, name, schema)
	if err != nil {
		return err
	}

	if _, ok := a.handlers[name]; ok {
		return fmt.Errorf("action handler %s already registered", name)
	}
	a.handlers[name] = handler

	l := ctxzap.Extract(ctx)
	l.Debug("registered action", zap.String("name", name))

	return nil
}

func (a *ActionManager) HasActions() bool {
	a.mu.RLock()
	defer a.mu.RUnlock()
	return len(a.schemas) > 0 || len(a.resourceSchemas) > 0
}

// RegisterResourceAction registers a resource-scoped action.
func (a *ActionManager) RegisterResourceAction(
	ctx context.Context,
	resourceTypeID string,
	schema *v2.BatonActionSchema,
	handler ActionHandler,
) error {
	if handler == nil {
		return errors.New("action handler cannot be nil")
	}
	if hasSecretReturnTypes(schema) {
		return errors.New("action schemas with secret return types must use RegisterResourceActionWithSecrets")
	}
	return a.registerResourceAction(ctx, resourceTypeID, schema, registeredActionHandler{
		invoke: func(ctx context.Context, args *structpb.Struct) actionHandlerResult {
			response, annos, err := handler(ctx, args)
			return actionHandlerResult{response: response, annotations: annos, err: err}
		},
	})
}

// RegisterResourceActionWithSecrets registers a resource-scoped action that
// returns plaintext secret values separately from its public response.
func (a *ActionManager) RegisterResourceActionWithSecrets(
	ctx context.Context,
	resourceTypeID string,
	schema *v2.BatonActionSchema,
	handler ActionHandlerWithSecrets,
) error {
	if schema == nil {
		return errors.New("action schema cannot be nil")
	}
	if handler == nil {
		return errors.New("action handler cannot be nil")
	}
	if !hasSecretReturnTypes(schema) {
		return errors.New("secret action handler requires at least one secret return type")
	}
	secretReturnNames, requiredSecretReturnNames, err := validateSecretReturnTypes(schema.GetReturnTypes())
	if err != nil {
		return err
	}
	return a.registerResourceAction(ctx, resourceTypeID, schema, registeredActionHandler{
		invoke: func(ctx context.Context, args *structpb.Struct) actionHandlerResult {
			response, plaintextData, annos, err := handler(ctx, args)
			return actionHandlerResult{response: response, plaintextData: plaintextData, annotations: annos, err: err}
		},
		secretReturnNames:         secretReturnNames,
		requiredSecretReturnNames: requiredSecretReturnNames,
	})
}

func (a *ActionManager) registerResourceAction(
	ctx context.Context,
	resourceTypeID string,
	schema *v2.BatonActionSchema,
	handler registeredActionHandler,
) error {
	if resourceTypeID == "" {
		return errors.New("resource type ID cannot be empty")
	}
	if schema == nil {
		return errors.New("action schema cannot be nil")
	}
	if schema.GetName() == "" {
		return errors.New("action schema name cannot be empty")
	}
	if handler.invoke == nil {
		return fmt.Errorf("handler cannot be nil for action %s", schema.GetName())
	}

	a.mu.Lock()
	defer a.mu.Unlock()

	// Set the resource type ID on the schema
	schema.SetResourceTypeId(resourceTypeID)

	if a.resourceSchemas[resourceTypeID] == nil {
		a.resourceSchemas[resourceTypeID] = make(map[string]*v2.BatonActionSchema)
	}
	if a.resourceHandlers[resourceTypeID] == nil {
		a.resourceHandlers[resourceTypeID] = make(map[string]registeredActionHandler)
	}

	actionName := schema.GetName()

	// Check for duplicate action names
	if _, ok := a.resourceSchemas[resourceTypeID][actionName]; ok {
		return fmt.Errorf("action schema %s already registered for resource type %s", actionName, resourceTypeID)
	}

	// Check for duplicate action types
	if len(schema.GetActionType()) > 0 {
		for existingName, existingSchema := range a.resourceSchemas[resourceTypeID] {
			if existingSchema == nil || len(existingSchema.GetActionType()) == 0 {
				continue
			}
			// Check if any ActionType in the new schema matches any in existing schemas
			for _, newActionType := range schema.GetActionType() {
				if newActionType == v2.ActionType_ACTION_TYPE_UNSPECIFIED || newActionType == v2.ActionType_ACTION_TYPE_DYNAMIC {
					continue // Skip unspecified and dynamic types as they can overlap
				}
				for _, existingActionType := range existingSchema.GetActionType() {
					if newActionType == existingActionType {
						return fmt.Errorf("action type %s already registered for resource type %s (existing action: %s)", newActionType.String(), resourceTypeID, existingName)
					}
				}
			}
		}
	}

	a.resourceSchemas[resourceTypeID][actionName] = schema
	a.resourceHandlers[resourceTypeID][actionName] = handler

	ctxzap.Extract(ctx).Debug("registered resource action", zap.String("resource_type", resourceTypeID), zap.String("action_name", actionName))

	return nil
}

// resourceTypeActionRegistry implements ResourceTypeActionRegistry for a specific resource type.
type resourceTypeActionRegistry struct {
	resourceTypeID string
	actionManager  *ActionManager
}

func (r *resourceTypeActionRegistry) Register(ctx context.Context, schema *v2.BatonActionSchema, handler ActionHandler) error {
	return r.actionManager.RegisterResourceAction(ctx, r.resourceTypeID, schema, handler)
}

func (r *resourceTypeActionRegistry) RegisterWithSecrets(ctx context.Context, schema *v2.BatonActionSchema, handler ActionHandlerWithSecrets) error {
	return r.actionManager.RegisterResourceActionWithSecrets(ctx, r.resourceTypeID, schema, handler)
}

// Deprecated: Use Register instead.
// RegisterAction registers a resource-scoped action. The name parameter is ignored; the name from schema is used.
func (r *resourceTypeActionRegistry) RegisterAction(ctx context.Context, name string, schema *v2.BatonActionSchema, handler ActionHandler) error {
	return r.Register(ctx, schema, handler)
}

// GetTypeRegistry returns an ActionRegistry for registering actions scoped to a specific resource type.
func (a *ActionManager) GetTypeRegistry(_ context.Context, resourceTypeID string) (ActionRegistry, error) {
	if resourceTypeID == "" {
		return nil, errors.New("resource type ID cannot be empty")
	}
	return &resourceTypeActionRegistry{resourceTypeID: resourceTypeID, actionManager: a}, nil
}

func (a *ActionManager) UnregisterAction(ctx context.Context, name string) error {
	a.mu.Lock()
	defer a.mu.Unlock()

	if _, ok := a.schemas[name]; !ok {
		return fmt.Errorf("action %s not registered", name)
	}
	delete(a.schemas, name)
	if _, ok := a.handlers[name]; !ok {
		return fmt.Errorf("action handler %s not registered", name)
	}
	delete(a.handlers, name)

	l := ctxzap.Extract(ctx)
	l.Debug("unregistered action", zap.String("name", name))

	// TODO: cancel & clean up outstanding actions?

	return nil
}

// ListActionSchemas returns all action schemas, optionally filtered by resource type.
// If resourceTypeID is empty, returns all global actions plus all resource-scoped actions.
// If resourceTypeID is set, returns only actions for that resource type.
func (a *ActionManager) ListActionSchemas(_ context.Context, resourceTypeID string) ([]*v2.BatonActionSchema, annotations.Annotations, error) {
	a.mu.RLock()
	defer a.mu.RUnlock()

	var rv []*v2.BatonActionSchema

	if resourceTypeID == "" {
		// Return all global actions
		rv = make([]*v2.BatonActionSchema, 0, len(a.schemas))
		for _, schema := range a.schemas {
			rv = append(rv, schema)
		}

		// Also return all resource-scoped actions
		for _, schemas := range a.resourceSchemas {
			for _, schema := range schemas {
				rv = append(rv, schema)
			}
		}
	} else {
		// Return only actions for the specified resource type
		schemas, ok := a.resourceSchemas[resourceTypeID]
		if !ok {
			return []*v2.BatonActionSchema{}, nil, nil
		}

		rv = make([]*v2.BatonActionSchema, 0, len(schemas))
		for _, schema := range schemas {
			rv = append(rv, schema)
		}
	}

	return rv, nil, nil
}

func (a *ActionManager) GetActionSchema(_ context.Context, name string) (*v2.BatonActionSchema, annotations.Annotations, error) {
	a.mu.RLock()
	defer a.mu.RUnlock()

	schema, ok := a.schemas[name]
	if !ok {
		return nil, nil, status.Error(codes.NotFound, fmt.Sprintf("action %s not found", name))
	}
	return schema, nil, nil
}

func (a *ActionManager) GetActionStatus(ctx context.Context, actionId string) (v2.BatonActionStatus, string, *structpb.Struct, annotations.Annotations, error) {
	status, name, response, _, annos, err := a.GetActionStatusWithEncryptedData(ctx, actionId)
	return status, name, response, annos, err
}

// GetActionStatusWithEncryptedData returns an outstanding action's public and
// encrypted results in one consistent snapshot.
func (a *ActionManager) GetActionStatusWithEncryptedData(
	_ context.Context,
	actionId string,
) (v2.BatonActionStatus, string, *structpb.Struct, []*v2.EncryptedData, annotations.Annotations, error) {
	a.mu.RLock()
	defer a.mu.RUnlock()

	oa := a.actions[actionId]
	if oa == nil {
		return v2.BatonActionStatus_BATON_ACTION_STATUS_UNKNOWN, "", nil, nil, nil, status.Error(codes.NotFound, fmt.Sprintf("action id %s not found", actionId))
	}

	// Don't return oa.Err here because error is for GetActionStatus, not the action itself.
	// oa.Rv contains any error.
	_, st, rv, encryptedData, annos := oa.resultWithEncryptedData()
	return st, oa.Name, rv, encryptedData, annos, nil
}

// InvokeAction invokes an action. If resourceTypeID is set, it invokes a resource-scoped action.
// Otherwise, it invokes a global action.
func (a *ActionManager) InvokeAction(
	ctx context.Context,
	name string,
	resourceTypeID string,
	args *structpb.Struct,
) (string, v2.BatonActionStatus, *structpb.Struct, annotations.Annotations, error) {
	return a.InvokeActionWithWait(ctx, name, resourceTypeID, args, 0)
}

// InvokeActionWithWait is InvokeAction with an explicit bound on how long the
// call may block waiting for the handler before returning the action's
// in-flight status; zero or negative keeps the default.
func (a *ActionManager) InvokeActionWithWait(
	ctx context.Context,
	name string,
	resourceTypeID string,
	args *structpb.Struct,
	inlineWait time.Duration,
) (string, v2.BatonActionStatus, *structpb.Struct, annotations.Annotations, error) {
	id, actionStatus, response, _, annos, err := a.InvokeActionWithWaitAndEncryption(
		ctx,
		name,
		resourceTypeID,
		args,
		inlineWait,
		nil,
	)
	return id, actionStatus, response, annos, err
}

// InvokeActionWithWaitAndEncryption invokes an action with recipients for any
// secret return values.
func (a *ActionManager) InvokeActionWithWaitAndEncryption(
	ctx context.Context,
	name string,
	resourceTypeID string,
	args *structpb.Struct,
	inlineWait time.Duration,
	encryptionConfigs []*v2.EncryptionConfig,
) (string, v2.BatonActionStatus, *structpb.Struct, []*v2.EncryptedData, annotations.Annotations, error) {
	clamped := clampInlineWait(inlineWait)
	if clamped < inlineWait {
		ctxzap.Extract(ctx).Warn("capping requested inline wait",
			zap.Duration("requested", inlineWait),
			zap.Duration("capped", clamped))
	}
	inlineWait = clamped

	if resourceTypeID != "" {
		return a.invokeResourceAction(ctx, resourceTypeID, name, args, inlineWait, encryptionConfigs)
	}

	return a.invokeGlobalAction(ctx, name, args, inlineWait, encryptionConfigs)
}

// invokeGlobalAction invokes a global (non-resource-scoped) action.
func (a *ActionManager) invokeGlobalAction(
	ctx context.Context,
	name string,
	args *structpb.Struct,
	inlineWait time.Duration,
	encryptionConfigs []*v2.EncryptionConfig,
) (string, v2.BatonActionStatus, *structpb.Struct, []*v2.EncryptedData, annotations.Annotations, error) {
	a.mu.RLock()
	handler, ok := a.handlers[name]
	schema, schemaOk := a.schemas[name]
	a.mu.RUnlock()

	if !ok {
		return "", v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED, nil, nil, nil, status.Error(codes.NotFound, fmt.Sprintf("handler for action %s not found", name))
	}
	if !schemaOk || schema == nil {
		return "", v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED, nil, nil, nil, status.Error(codes.Internal, fmt.Sprintf("schema for action %s not found", name))
	}

	return a.invokeRegisteredAction(ctx, name, "", args, inlineWait, encryptionConfigs, schema, handler)
}

// invokeResourceAction invokes a resource-scoped action.
func (a *ActionManager) invokeResourceAction(
	ctx context.Context,
	resourceTypeID string,
	actionName string,
	args *structpb.Struct,
	inlineWait time.Duration,
	encryptionConfigs []*v2.EncryptionConfig,
) (string, v2.BatonActionStatus, *structpb.Struct, []*v2.EncryptedData, annotations.Annotations, error) {
	if resourceTypeID == "" {
		return "", v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED, nil, nil, nil, status.Error(codes.InvalidArgument, "resource type ID is required")
	}
	if actionName == "" {
		return "", v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED, nil, nil, nil, status.Error(codes.InvalidArgument, "action name is required")
	}

	a.mu.RLock()
	handlers, ok := a.resourceHandlers[resourceTypeID]
	if !ok {
		a.mu.RUnlock()
		return "", v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED, nil, nil, nil, status.Error(codes.NotFound, fmt.Sprintf("no actions found for resource type %s", resourceTypeID))
	}

	handler, ok := handlers[actionName]
	if !ok {
		a.mu.RUnlock()
		return "",
			v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED,
			nil,
			nil,
			nil,
			status.Error(codes.NotFound, fmt.Sprintf("handler for action %s not found for resource type %s", actionName, resourceTypeID))
	}

	schemas, ok := a.resourceSchemas[resourceTypeID]
	if !ok {
		a.mu.RUnlock()
		return "", v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED, nil, nil, nil, status.Error(codes.Internal, fmt.Sprintf("schemas not found for resource type %s", resourceTypeID))
	}

	schema, ok := schemas[actionName]
	if !ok {
		a.mu.RUnlock()
		return "", v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED, nil, nil, nil, status.Error(codes.Internal, fmt.Sprintf("schema not found for action %s", actionName))
	}
	a.mu.RUnlock()

	return a.invokeRegisteredAction(ctx, actionName, resourceTypeID, args, inlineWait, encryptionConfigs, schema, handler)
}

func (a *ActionManager) invokeRegisteredAction(
	ctx context.Context,
	actionName string,
	resourceTypeID string,
	args *structpb.Struct,
	inlineWait time.Duration,
	encryptionConfigs []*v2.EncryptionConfig,
	schema *v2.BatonActionSchema,
	handler registeredActionHandler,
) (string, v2.BatonActionStatus, *structpb.Struct, []*v2.EncryptedData, annotations.Annotations, error) {
	if err := validateActionConstraints(schema.GetConstraints(), args); err != nil {
		return "", v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED, nil, nil, nil, status.Error(codes.InvalidArgument, err.Error())
	}

	var encryptionManager *crypto.EncryptionManager
	if len(handler.secretReturnNames) > 0 {
		if len(encryptionConfigs) == 0 {
			return "", v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED, nil, nil, nil, status.Error(codes.InvalidArgument, "at least one encryption config is required for secret action results")
		}
		encryptionConfigs = cloneEncryptionConfigs(encryptionConfigs)
		if err := crypto.ValidateEncryptionConfigs(encryptionConfigs); err != nil {
			return "", v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED, nil, nil, nil, err
		}
		var err error
		encryptionManager, err = crypto.NewEncryptionManager(nil, encryptionConfigs)
		if err != nil {
			return "", v2.BatonActionStatus_BATON_ACTION_STATUS_FAILED, nil, nil, nil, status.Errorf(codes.InvalidArgument, "create encryption manager: %v", err)
		}
	}

	oa := a.GetNewAction(actionName)
	done := make(chan struct{})

	// The handler runs detached. Return its final result if it finishes
	// within the inline wait; otherwise return the in-flight status.
	go func() { // #nosec G118 -- action handlers intentionally outlive the request context and keep only trace/log metadata.
		defer close(done)
		defer func() {
			if r := recover(); r != nil {
				if len(handler.secretReturnNames) > 0 {
					ctxzap.Extract(ctx).Error("panic in action handler",
						zap.String("resource_type", resourceTypeID),
						zap.String("action", actionName),
						zap.Stack("stack"))
					oa.SetError(ctx, errors.New("panic in action handler"))
				} else {
					ctxzap.Extract(ctx).Error("panic in action handler",
						zap.String("resource_type", resourceTypeID),
						zap.String("action", actionName),
						zap.Any("panic", r),
						zap.Stack("stack"))
					oa.SetError(ctx, fmt.Errorf("panic in action handler: %v", r))
				}
			}
		}()
		oa.SetStatus(ctx, v2.BatonActionStatus_BATON_ACTION_STATUS_RUNNING)
		bgCtx := trace.ContextWithSpanContext(context.Background(), trace.SpanContextFromContext(ctx))
		bgCtx = ctxzap.ToContext(bgCtx, ctxzap.Extract(ctx))
		handlerCtx, cancel := context.WithTimeoutCause(bgCtx, 1*time.Hour, errors.New("action handler timed out"))
		defer cancel()
		result := handler.invoke(handlerCtx, args)
		encryptedData, resultErr := prepareActionResult(
			handlerCtx,
			handler,
			encryptionManager,
			a.encryptPlaintext,
			result.response,
			result.plaintextData,
			result.err == nil,
		)
		if resultErr != nil {
			result.response = nil
			result.err = errors.Join(result.err, resultErr)
		}
		oa.setOutcomeWithEncryptedData(ctx, result.response, encryptedData, result.annotations, result.err)
	}()

	// Stop releases the timer deterministically when the handler wins the
	// select; an abandoned time.After timer would only be GC-eligible.
	waitTimer := time.NewTimer(inlineWait)
	defer waitTimer.Stop()

	select {
	case <-done:
		id, st, rv, encryptedData, annos := oa.resultWithEncryptedData()
		return id, st, rv, encryptedData, annos, nil
	case <-waitTimer.C:
		id, st, rv, encryptedData, annos := oa.resultWithEncryptedData()
		return id, st, rv, encryptedData, annos, nil
	case <-ctx.Done():
		// The handler may have finished in the same instant; prefer its
		// completed result over a spurious cancellation return.
		select {
		case <-done:
			id, st, rv, encryptedData, annos := oa.resultWithEncryptedData()
			return id, st, rv, encryptedData, annos, nil
		default:
		}
		oa.setCancelled(ctx, ctx.Err())
		id, st, rv, encryptedData, annos := oa.resultWithEncryptedData()
		if st == v2.BatonActionStatus_BATON_ACTION_STATUS_COMPLETE {
			// The handler won the race to the lock; its completed result is
			// the authoritative pairing, not the cancellation.
			return id, st, rv, encryptedData, annos, nil
		}
		return id, st, rv, encryptedData, annos, ctx.Err()
	}
}

func hasSecretReturnTypes(schema *v2.BatonActionSchema) bool {
	if schema == nil {
		return false
	}
	for _, field := range schema.GetReturnTypes() {
		if field.GetIsSecret() {
			return true
		}
	}
	return false
}

func validateSecretReturnTypes(returnTypes []*config.Field) (map[string]struct{}, []string, error) {
	seen := make(map[string]struct{}, len(returnTypes))
	requiredNames := make([]string, 0)
	for _, field := range returnTypes {
		if field == nil || !field.GetIsSecret() {
			continue
		}
		name := field.GetName()
		if name == "" {
			return nil, nil, errors.New("secret return type name cannot be empty")
		}
		if _, ok := seen[name]; ok {
			return nil, nil, fmt.Errorf("duplicate secret return type %q", name)
		}
		seen[name] = struct{}{}
		if field.GetIsRequired() {
			requiredNames = append(requiredNames, name)
		}
	}
	return seen, requiredNames, nil
}

func cloneEncryptionConfigs(configs []*v2.EncryptionConfig) []*v2.EncryptionConfig {
	cloned := make([]*v2.EncryptionConfig, len(configs))
	for i, config := range configs {
		if config != nil {
			cloned[i] = proto.Clone(config).(*v2.EncryptionConfig)
		}
	}
	return cloned
}

func prepareActionResult(
	ctx context.Context,
	handler registeredActionHandler,
	encryptionManager *crypto.EncryptionManager,
	encryptPlaintext actionEncryptFunc,
	response *structpb.Struct,
	plaintextData []*v2.PlaintextData,
	encrypt bool,
) ([]*v2.EncryptedData, error) {
	if len(handler.secretReturnNames) == 0 {
		return nil, nil
	}

	for name := range response.GetFields() {
		if _, ok := handler.secretReturnNames[name]; ok {
			return nil, fmt.Errorf("secret return value %q must not be included in the public response", name)
		}
	}

	seen := make(map[string]struct{}, len(plaintextData))
	for i, plaintext := range plaintextData {
		if plaintext == nil || plaintext.GetName() == "" || len(plaintext.GetBytes()) == 0 {
			return nil, fmt.Errorf("plaintext return value %d must have a name and non-empty bytes", i)
		}
		if _, ok := handler.secretReturnNames[plaintext.GetName()]; !ok {
			return nil, fmt.Errorf("plaintext return value %q is not declared as a secret return type", plaintext.GetName())
		}
		if _, ok := seen[plaintext.GetName()]; ok {
			return nil, fmt.Errorf("duplicate plaintext return value %q", plaintext.GetName())
		}
		seen[plaintext.GetName()] = struct{}{}
	}

	if !encrypt {
		return nil, nil
	}

	for _, name := range handler.requiredSecretReturnNames {
		if _, ok := seen[name]; !ok {
			return nil, fmt.Errorf("required secret return type %q is missing", name)
		}
	}

	var encryptedData []*v2.EncryptedData
	for _, plaintext := range plaintextData {
		encrypted, err := encryptPlaintext(ctx, encryptionManager, plaintext)
		if err != nil {
			return nil, fmt.Errorf("encrypt action return value %q: %w", plaintext.GetName(), err)
		}
		encryptedData = append(encryptedData, encrypted...)
	}
	return encryptedData, nil
}

// validateActionConstraints validates that the provided args satisfy the schema constraints.
func validateActionConstraints(constraints []*config.Constraint, args *structpb.Struct) error {
	if len(constraints) == 0 {
		return nil
	}

	// Build map of present fields (non-null values in struct)
	present := make(map[string]bool)
	if args != nil {
		for fieldName, value := range args.GetFields() {
			if !isNullValue(value) {
				present[fieldName] = true
			}
		}
	}

	// Validate each constraint
	for _, constraint := range constraints {
		if err := validateConstraint(constraint, present); err != nil {
			return err
		}
	}
	return nil
}

func validateConstraint(c *config.Constraint, present map[string]bool) error {
	// Deduplicate field names to handle cases where the same field is listed multiple times
	uniqueFieldNames := deduplicateStrings(c.GetFieldNames())

	// Count how many unique primary fields are present
	var primaryPresent int
	for _, name := range uniqueFieldNames {
		if present[name] {
			primaryPresent++
		}
	}

	switch c.GetKind() {
	case config.ConstraintKind_CONSTRAINT_KIND_REQUIRED_TOGETHER:
		if primaryPresent > 0 && primaryPresent < len(uniqueFieldNames) {
			return fmt.Errorf("fields required together: %v", uniqueFieldNames)
		}
	case config.ConstraintKind_CONSTRAINT_KIND_MUTUALLY_EXCLUSIVE:
		if primaryPresent > 1 {
			return fmt.Errorf("fields are mutually exclusive: %v", uniqueFieldNames)
		}
	case config.ConstraintKind_CONSTRAINT_KIND_AT_LEAST_ONE:
		if primaryPresent == 0 {
			return fmt.Errorf("at least one required: %v", uniqueFieldNames)
		}
	case config.ConstraintKind_CONSTRAINT_KIND_DEPENDENT_ON:
		if primaryPresent > 0 {
			// Deduplicate secondary field names and check they are all present
			uniqueSecondaryFieldNames := deduplicateStrings(c.GetSecondaryFieldNames())
			for _, name := range uniqueSecondaryFieldNames {
				if !present[name] {
					return fmt.Errorf("fields %v depend on %v which must also be present", uniqueFieldNames, uniqueSecondaryFieldNames)
				}
			}
		}
	case config.ConstraintKind_CONSTRAINT_KIND_UNSPECIFIED:
		return nil
	default:
		return fmt.Errorf("unknown constraint kind: %v", c.GetKind())
	}
	return nil
}

// deduplicateStrings returns a new slice with duplicate strings removed, preserving order.
func deduplicateStrings(input []string) []string {
	seen := make(map[string]bool)
	result := make([]string, 0, len(input))
	for _, s := range input {
		if !seen[s] {
			seen[s] = true
			result = append(result, s)
		}
	}
	return result
}

func isNullValue(v *structpb.Value) bool {
	if v == nil {
		return true
	}
	_, isNull := v.GetKind().(*structpb.Value_NullValue)
	return isNull
}
