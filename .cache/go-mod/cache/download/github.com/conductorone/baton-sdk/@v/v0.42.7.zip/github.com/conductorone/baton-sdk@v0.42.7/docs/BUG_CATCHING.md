# Bug-catching guidance for baton-sdk

Guidance for finding bugs in this repo — written for AI agents and humans alike.
Derived from a multi-agent review of the incremental grant-expansion branch (4
verified correctness/soundness bugs), cross-validated against the repo's historical
fix commits, and revised against the type-scoped/fan-out branch's record (5
adversarial review rounds, ~18 confirmed bugs — including the worst one, which no
review round found). Status: draft under active refinement.

This file stays terse and checkable: every sentence should be a check an agent can
run, a criterion it can apply, or one line of evidence with a citation. It is
self-contained; §7 resolves the effort shorthand the evidence bullets use.

How to use it: §1 is the repo's failure model — read it first. §2 routes the
change's risk to instruments *before* review rounds are spent. §3 is the review
itself (seven passes). §4 is what to do with each confirmed finding. §5 is the
pattern checklist to prompt passes with. §6 is process mechanics. §7 resolves the
effort shorthand ("fan-out branch", "timeout effort") used in evidence bullets.

## 1. Why this repo breaks the way it does

baton-sdk is a **stateful pipeline over durable artifacts**. Sync state lives in three
places at once — the sync token, the c1z contents, and in-memory syncer state — and
they constantly disagree mid-flight; that's normal. The invariant is:

> **Disagreement is fine; durable divergence is not.**

At every point where execution can stop (checkpoint written, sync sealed, artifact
published, process killed), the surviving state must be either self-consistent or
safely regenerable from what survived. Most real bugs here are not logic errors inside
a function; they are transient disagreements that got **made durable** — a sidecar
fsync'd before the grants it describes, a copied artifact keeping metadata from its
source, a token checkpointed mid-cleanup that a resumed process trusts.

Corollaries:

- **Execution is distributed.** Connectors run as child processes in lambdas/containers
  with no sticky routing — a resume, a retry, or the next page of the same listing may
  execute on a different machine. State that isn't in the sync token or the c1z does
  not exist. In-memory caches, connector-side sessions, temp files, and "we already
  fetched this" assumptions are all invalid across any task boundary.
- **The session store is a network service, not a cache.** It looks like a local map
  but is parent-process gRPC locally and a *separate gRPC service* in prod, with
  different implementations, failure modes, and consistency behavior per environment
  (`pkg/session`: client/server split, memory and noop variants).
- **A contract is only as strong as its consumers.** SDK error codes, checkpoint
  semantics, and preservability classifications are required by the c1 host,
  which can silently neutralize them (timeout effort: a host-side rewrap stripped
  the status that made timeouts retryable). Review a changed contract *at its
  consumers*, and put the contract test on the consumer side of the boundary — the two
  highest-impact bugs of that effort were invisible from inside either repo alone.
- **SQLite is deprecated** — major bug fixes only. Pebble is the target engine. New
  features may be Pebble-only *by design*, with graceful degradation (feature cleanly
  disabled, not broken) on SQLite.
- **Degradation must be visible in proportion to exposure.** A *feature* cleanly
  disabled is an Info line; a *safety check* silently skipped makes a never-validated
  artifact indistinguishable from one that passed. The referential invariants skipped
  on SQLite logged at Info while type-scoped connectors depended on exactly those
  checks — the escalation to Warn came only from a dedicated invariant audit, not
  from any review round.

Review accordingly: for each write, ask "if we stop right after this — possibly
restarting elsewhere — what does the survivor believe, and is it wrong?" Trace state
ownership and stop-points first, function bodies second.

## 2. Review has no closure criterion — route bug classes to instruments first

### Risk triage: score the failure mode, not the subsystem

Risk is **escape × consequence**: how likely a defect ships and survives, times
what it costs to undo. Path lists ("sync, checkpointing, serialization…") are
projections of these axes and rot as the code moves; the axes don't.

**Escape axes** — how likely a defect ships and persists:

1. **Silence** — if this code is wrong, what makes noise? A panic is low; a
   well-formed wrong row is high. (No grep for this one; it's assessed.)
2. **Durability** — does any effect outlive the process? Persisted output has
   unbounded temporal blast radius: it will be read by code that doesn't exist
   yet. Durable *and* version-crossing (tokens, c1z, session values) outranks
   durable-and-local.
3. **Uncontrolled dimensions** — does correctness or liveness depend on
   schedule, crash timing, environment faults, the version pair, or **data
   volume**? Scale is the dimension local testing systematically undersamples:
   an O(n²) pass is correct at every N and dead at whale N, and fixtures never
   reach whales.
4. **Consumer distance** — who interprets this output: the next line, another
   process, another repo, a future SDK version? Error codes, config schemas,
   and exported contracts are remote-consumer surfaces even when they look like
   plumbing.

**Consequence — the remediation ladder.** Score what unfucking costs, not how
bad it sounds:

1. **Redeploy** — defect lives in code only; ship a fix.
2. **Re-sync** — bad state in our own artifacts; regenerable from source.
3. **Migrate** — every artifact in the fleet must be visited, under budgets, at
   whale scale. (The remediation is itself a migration — see the intersection
   class below.)
4. **Coordinate** — the contract itself is wrong: version bumps and lockstep
   changes across repos and deployments we don't control. (Evidence: the c1z
   spec break that forced a new SDK version — the cost was not the bug but the
   compatibility matrix stood up after the fact.)
5. **Irrecoverable** — external side effects: provisioning writes, credential
   operations, deletions in customer systems. No remediation exists, only
   prevention.

**Verdict rules:**

- **Silent + durable is HIGH**, and it compounds: every day undetected, more
  artifacts carry the defect, so detection latency converts escape into
  consequence — a format defect's migration bill grows with time-to-detection.
- **Version-pair dependence that affects correctness, liveness, or durable meaning
  is HIGH** (the class review cannot see at all). Ordinary additive protobuf
  evolution that passes compatibility checks is not HIGH merely because old and new
  binaries see different field sets.
- **Remediation rung ≥ 4 is HIGH regardless of escape score**, and flips the
  defense from detection to prevention: golden artifact corpus for formats
  (old artifacts in testdata opened by the new SDK; new artifacts opened by a
  pinned old SDK), dry-run/plan-apply and idempotency-by-identity for external
  effects, staged rollout for contracts.
- Otherwise, two or more escape yeses ⇒ HIGH.
- **Exposure modifies the verdict**: default-path changes outrank option-gated
  ones (§5.8's caveat applies — "gated" claims rot).

**Cost contracts.** On a short declared list of hot paths — grant expansion,
compaction, the per-checkpoint loop, anything that runs at artifact-open time —
performance is a correctness property when a change alters executed work:
budgets convert latency into deadline cascades, and fixed memory converts
peak-RSS into an OOM crash loop (same artifact, same ceiling, same kill:
livelock). The reviewable object is the **cost curve** — state the big-O delta
in grants/entitlements/graph size; "fine at fixture scale" is not a claim —
enforced by a whale-scale benchmark ratcheted against main (allocations, not
noisy CI wall-clock; the killer is accretion — nobody ships a 2×, five people
ship 15%s). If a stage introduces no runtime path or cost-curve change, state
that instead. A claimed cost contract without a benchmark is dead prose.

**Migrations are the intersection class**: they run once per artifact at open
time, inside someone else's deadline, at whale scale, on data written by past
versions, on by default fleet-wide, behind a one-way format door. Chunked and
resumable is mandatory — each attempt makes durable forward progress (§5.7) —
because an over-budget migration retries the same artifact into a permanent
every-sync failure. (Evidence: the grant migration whose cost curve failed
every sync in prod; same class as #911.)

High-risk changes get §2's routing (instrument before review rounds) and the
full pass set; the "cannot-be-reviewed" criterion below is this triage's
extreme end. Evidence the axes beat the intuitive list: the GUI-default
coupling (#1024, a "mere" config field — axis 4) and the Lambda clock-freeze
(#1005, "mere" HTTP plumbing — axes 2+3) were high-risk changes no path list
would have flagged, while the age branch cleared every axis except consumer
distance — exactly where its one residual risk sat.

### The frame: coverage-driven verification

The frame is borrowed from hardware design verification (**coverage-driven
verification** — the cleanest existence proof that an industry facing
invisible-failure bug classes abandoned inspection-as-confidence and survived).
Three named parts: a **verification plan**, written before the bug hunt, states the
spaces to cover and the contracts that must hold over them; a **coverage model**
enumerates that space mechanically (never "we looked carefully"); **closure** is
the sign-off — the model exhausted, every assertion held. Done is a measurement,
not a feeling.

Multiple models may contribute candidate criteria during plan creation. The
orchestrator merges them, removes duplicates, resolves contradictions, assigns
stable criterion IDs, runs a final contract-to-criteria completeness audit, and
explicitly freezes the result before implementation inspection. Expansion during
synthesis is useful; uncontrolled revision after the freeze is not.

Review is sampling of the behavior space with no coverage model attached. After any
number of rounds no one can state what fraction of the space was inspected, so
"review converged" is not slow to reach — it is *undefined*. What review is for:
**discovering the plan** — the contracts worth stating ("spawned cursors must
drain") and the axes worth sweeping ("the resumer may be a different version") —
and finding bugs in cells already written down. Reviewers write the verification
plan; instruments close it.

Policy, stated up front:

A change meets the **step-up criteria** when §2 rates it HIGH or it meets the
silent/combinatorial/no-single-run-oracle criterion. For changes that meet the
step-up criteria:

- Commit the implementation-blind plan to the feature branch before
  implementation inspection, under `docs/verification/<change>/plan.md`, with
  the evidence record beside it as `evidence.md`; the draft PR links both, and
  both survive merge so local and remote reviewing agents receive the same
  versioned inputs. The first plan commit is the frozen baseline. Post-freeze
  changes append as versioned **change orders** — a *correction* (required by
  the original contract; current stage/PR), a *clarification* (wording or
  enforcement ownership, behavior unchanged; boundary-resolution note), or an
  *extension/optimization* (behavior, schema, lifecycle, or performance
  machinery beyond original closure; separate staged PR and addendum) — each
  recording source, motivation, contract delta, owning boundary, affected
  criteria, verification delta, and PR placement. Never silently rewrite prior
  criteria or evidence: the change-order log lives in Git history and the
  committed plan; gists, PR comments, and attachments are supplemental, never
  the sole copy. After merge the plan preserves intent, scope, ownership, and
  evidence provenance; tests, harnesses, and benchmarks remain the enduring
  enforcement mechanism.
- Re-route every change order through the risk model. A "small fix" that
  introduces a new helper, resource owner, durable write, or retry boundary
  gets the focused review passes and instrument delta for those new mechanics
  — inherited behavioral evidence does not cover newly introduced hazards —
  and affected criterion states update before closure is re-reported.
- The plan may span **staged PRs**. Each names its stage, the claims it
  introduces, the criteria due now, and the criteria deliberately deferred
  until a later stage has an executable subject. Closure is scoped to the
  current stage; deferred criteria limit whole-plan closure but are not
  current-stage gaps.
- Every criterion due in the current stage gets its own closure entry mapping
  it to an executable repository artifact and evidence that it ran and held at
  the claimed coverage level — or recording the explicit gap and the resulting
  limit on that stage's closure. The entry names the required and covered
  cells, any reduction, the exact artifact and assertion, the tested layer,
  premise assertion, oracle, instrument validation, evidence command/revision,
  and status; one table-driven test may satisfy many entries, and ranges may
  summarize only after the individual entries exist. State whether each
  artifact provides bounded closure or measured sampling — never claim closure
  from sampling — and treat a required instrument that does not exist as
  leaving every dependent criterion evidence incomplete. Keep the ledger in
  Markdown or generated test cases; build a framework only when repetition or
  drift justifies it.
- Test each obligation at the layer that owns it and across the boundary that
  could lose it — typed/raw mutation, engine operation, public capability,
  close/reopen artifact — without duplicating identical pure logic at every
  layer. A schema-only stage closes schema obligations (lint, compatibility,
  generation, descriptors, wire shape), not speculative runtime validators;
  producer/consumer semantics come due in the first stage that implements or
  relies on them, and validation the schema itself encodes is due now. An
  ordering test must invoke the component that owns the ordering decision: a
  hand-sequenced `put → delete → delete` proves storage composition, not that
  an orchestrator chooses that order — if the owner is deferred, so is the
  ordering criterion. Enforcement ownership may remain unresolved during blind
  planning (it blocks defect classification, not plan or oracle design) and
  resolves through a versioned boundary addendum after API discovery, which
  may locate enforcement but never weakens required behavior to match the
  implementation.
- After implementation inspection, append an **implementation-obligation
  addendum** before classifying evidence. Inventory changed or
  current-stage-reachable mechanics the behavioral contract could not name:
  acquired closers/iterators/batches/locks and ownership transfers; dirty
  flags, caches, counters, and sidecars; derived fast-path state (§5.11);
  partial-commit cuts; and public wrappers around engine mutations. Assign
  each an invariant, failure premise, oracle, and owning layer. This is
  implementation-derived coverage, not permission to revise the frozen
  behavior. Group call sites only when inspection confirms they share the
  relevant choke point and obligations; implementation divergence invalidates
  a symmetry reduction.
- Track each current-stage criterion as exactly one of: **not assessed,
  evidence incomplete, verified to stated coverage, failed, explicitly
  excluded, or deferred to a named stage**. "Every criterion is accounted for"
  is not closure: verification requires an executable oracle, the claimed
  dimensions covered or explicitly reduced, a validated instrument, and
  passing evidence commands. A relevant implementation, instrument, fixture,
  or plan change returns affected verified entries to evidence incomplete
  until their instruments rerun at the recorded revision.
- **Closure is a rate, not a checklist.** Hardware signs off on a flattened
  bug-discovery curve, not a finished test list. Declaring closure for a
  step-up change requires, beyond dispositioned criteria: the latest
  decorrelated implementation read and the latest independent evidence audit
  each ran against the *final* code and produced zero new findings, and —
  where a model-based or randomized instrument exists — a clean soak at the
  final revision. Any post-fix change restarts the clock (§6's
  per-change-order review budget). (Evidence: sync-replay declared closure
  three times with a complete checklist each time; each decorrelated read
  found new highs — the curve had not flattened.)

- **Stopping rule: budget two, at most three review rounds**, then switch
  instruments. Review coverage is unmeasurable, so the budget is an economic
  cutoff, not an epistemic one; "the last round was clean" measures the reviewers
  as much as the code. (Corroboration: 15+ rounds without convergence, sync-replay
  effort; new high-severity bugs every round for 5 rounds, fan-out branch.)
- **Decorrelate reviewers**: on identical prompts, four models found nearly disjoint
  bug sets. Multiple models is coverage, not redundancy.
- **Prompts are not capabilities.** The worst bug on record — cross-version
  checkpoint resume silently sealing an incomplete sync — survived 5 adversarial
  rounds whose Pass 2 prompt *explicitly named the scenario*, and fell to a
  two-artifact harness in an afternoon, by counting rows. Reading cannot execute the
  other artifact.

**Validate the instrument before trusting its verdict.** Both halves: the setup
actually created the intended premise or fault, and the oracle fails on a planted
representative violation. A red test may indicate a product defect, an invalid
premise, an incorrect oracle, or unresolved boundary ownership — classify which
before changing production code. Concretely: a rejection test asserts the expected
error class and must not pass on an unexpected setup error; a fault test asserts
the hook actually fired; a forbidden-mutation test seeds non-empty target state
and compares complete before/after snapshots (an empty destination cannot detect
clear-before-validation; key counts cannot detect value mutation). Assert
postconditions at the plan's stated strength: a digest is not replaced by a key
count, provenance is not replaced by proto equality, and durable state is not
inferred from live state. Keep the oracle independent of the behavior under test:
a filtered public lookup cannot prove malformed raw state was never stored when
that same lookup intentionally hides it — inspect raw state or use a separately
derived model. One planted violation per distinct oracle or failure mechanism is
enough; do not mutation-test every cross-product cell unless it reaches a
materially different path.

**For durable mutations, the outer lifecycle is part of the instrument**:
`invoke → inspect live state → close → reopen → inspect durable state`, through
the public capability when it owns persistence. Cover success, zero-result
success, failure before mutation, failure after every committed cut, and
cancellation/retry where supported. Derive the commit sites from the
implementation: every loop that commits is its own cut, not only the headline
one, and each site owes §5.12's six answers (sync-replay: replacement ran a
destructive clear loop before its copy loop, with the same dirty/cache/fast-path
obligations and no hook). Equivalent repeated chunks may share one
representative cut; distinct commit sites may not.

Four classes review is structurally blind to, and where to send them:

- **Multi-artifact properties** — any property that is a function of more than one
  artifact: two SDK versions (checkpoint skew), two storage engines, current code +
  data written by past code, spec + implementation. Instrument: an execution harness
  that instantiates *both* artifacts and compares counted results against ground
  truth, in both directions.
- **Emergent schedule properties** — data races, lost wakeups, livelocks.
  Instruments: `-race` on affected packages as the minimum, with the full suite as a
  hard gate for shared scheduler/storage changes or in CI (it found in minutes what
  every review round missed); randomized soak (topology + failure injection, many
  seeds) under race; bounded-exhaustive interleaving harnesses for small lock-based
  objects. Review still owns the *logic-level* concurrency bugs (abort-path commits,
  TOCTOU admission) — that is Pass 7's job.
- **Absence bugs** — code that should exist but doesn't; review verifies only what
  is written. (Fan-out: spawned cursors were never wired into the worker batch —
  every path a reviewer read looked complete.) Instruments: positive-evidence
  runtime invariants (enroll at admission, reconcile at quiesce — §4 rung 3);
  contract-coverage mapping (every behavioral sentence in a proto/doc contract maps
  to a test that fails if the sentence is false once a producer or consumer claims
  to implement that behavior; schema-only stages record that obligation as
  deferred).
- **Error-path properties** — code that runs only when the environment fails.
  Review reads it; nothing executes it, because ordinary tests run over an
  implicitly cooperative environment (disks persist, RPCs return, deadlines never
  fire). Instrument: fault injection at a hook, with a stated recovery contract as
  the oracle (§5.10; house example: the engine errorfs sweep — every write/fsync
  failure in the EndSync window must reopen as resumable-unfinished or
  finished-and-complete, exhaustively).

### Subsystems that cannot be reviewed or ad-hoc-tested into confidence

Recognition criterion — all three must hold:

1. **Failures are silent**: absence, a hang, or well-formed wrong data — no error,
   no log line. (A hung scheduler looks like a slow sync; a dropped cursor looks
   like a smaller customer.)
2. **The behavior space is a product of uncontrolled dimensions** — worker
   schedules × crash/checkpoint cut points × version pairs × retry timings. Ad-hoc
   tests sample it at measure zero; a reviewer simulates exactly one schedule: the
   intended one.
3. **The oracle is not observable in any single execution** — correctness is
   defined against something no run exhibits (what the store *would* contain
   uninterrupted). The oracle must be constructed.

House example: the parallel scheduler + checkpoint/resume boundary (5 adversarial rounds
did not converge on it; from first principles, should not have). For such
subsystems, the only conversion of effort into confidence is **verification as a
design deliverable**:

1. **State the contract as explicit properties** — exactly-once execution, dedup
   soundness, termination, transition atomicity, bounded memory, crash-cut
   consistency. If the property list can't be written, the design is not done.
2. **Construct the oracle** — without it a silent failure has nothing to fail
   against:
   *self-equivalence* (an interrupted-and-resumed run must produce the same sealed
   store as an uninterrupted one); *derived ground truth* (a deterministic topology
   makes the expected store computable); *contract audit* (record the operation
   log, check it against the properties post-hoc).
3. **Mechanically cover a stated space** — every checkpoint cut point of a
   deterministic sync, all interleavings of a bounded configuration, N seeds of an
   adversarial grammar. Coverage of a *stated* space converts effort into
   confidence; review rounds and ad-hoc tests accumulate effort with unknown
   coverage. Claim **closure** only where the space is bounded and exhausted (the
   errorfs EndSync-window sweep, with its completeness proof); a seeded soak is
   *measured sampling*, not closure — the verification plan states which one each
   instrument claims.
4. **The harness is part of the subsystem** — designed and maintained with it, of
   comparable size and status. Here the §4 ladder inverts: rungs 2–3 are the
   *starting point* of the design, not the escalation path after a bug.

Production complement, not substitute: runtime positive-evidence invariants and
reconciliation ledgers (§4 rung 3) make a slice of the silent class loud in
operation, but liveness failures and anything they don't ledger stay invisible —
the verification harness is the only instrument for the rest.

## 3. Seven risk-routed review passes

Treat these passes as a menu selected from the current stage's claims and §2 risk
triage. HIGH changes with broad behavioral impact get the full set; narrow changes
get only the passes whose failure models they can activate. Record why omitted
passes are out of scope. Separate, separately-prompted reviewer agents per selected
pass work well (see §6). If risk concentrates in a multi-artifact, schedule, absence,
or error-path class, build the harness before spending review rounds.

### Pass 1: Edge cases

Empty/nil inputs, first-run vs. incremental, the referenced thing was deleted,
duplicates, partial vs. full sync types. Repo-specific: multi-valued annotations
(`entitlement_ids`), cycle-collapsed graph nodes, dangling refs (skip-with-warn
conventions). Engines: Pebble is the target; verify SQLite degradation paths return
clean nils/no-ops, not errors — and flag new SQLite feature-parity work as probably
wasted effort.

### Pass 2: Checkpointing & resuming

For every point execution can stop: does what survives stay consistent *or
regenerable*? Can the same checkpoint be resumed twice without double-apply? Does
write-durability ordering (`pebble.Sync` vs. `NoSync` vs. EndSync flush) match what
the state claims? Are sealed-window writes (`AllowSealed`) justified? Assume the
resumer is a different process on a different machine with a cold cache — possibly a
different SDK version. If correctness depends on anything the previous process knew
but didn't persist, it's broken.

Reading can only *ask* these questions; §2's harnesses answer them. When the current
stage changes durable state, stop points, or resume semantics, mechanize the
stop-point sweep: hook the checkpoint call, capture every token a deterministic sync
writes, resume a fresh process from each one, and assert the final store matches the
uninterrupted run. Resume each token twice (double-apply), and resume under a
different worker count when scheduling is relevant. A correctness-relevant
cross-version cell needs the two-artifact harness.

### Pass 3: Systematic permutation coverage

When behavior is parameterized by multiple dimensions — (in base? × in current?),
(edge spec: shallow/deep × filter wider/narrower/same), (sync type × engine × option
flags), (error category × recovery obligation) — write out the dimensions explicitly,
form the cross-product, and account for every cell: handled, collapsed by symmetry, or
excluded with a stated reason. **Bugs live in the cells nobody wrote down.** Reviewers
should ask for the table, not read the if-branches and try to reconstruct it.

- The coverage model names the full dimensions but need not instantiate a literal
  Cartesian product when interactions are irrelevant or symmetric. Record the
  reduction rule: symmetry, shared choke point, pairwise interaction,
  representative failure mechanism, or unrepresentable API cell. Reduced or sampled
  coverage must not be reported as bounded exhaustive closure.
- A reduction must explain why the removed dimension cannot affect the property.
  Never collapse result cardinality with mutation cardinality: zero emitted/copied
  rows may still clear destination state, commit cleanup, advance metadata, or
  require persistence. Cross boundary-sensitive dimensions before applying
  symmetry. After implementation inspection, confirm the reduced cells use the same
  relevant path; a kind-specific fallback, parser, cleanup, or wrapper invalidates
  the reduction for that obligation.
- When sibling families (per-kind flags, per-family indexes, per-type cleanup) each
  owe the same obligation, enumerate family × lifecycle boundary mechanically. A
  shared field group or similarly named methods are not a shared choke point —
  compare the actual set/clear/consume call sites — and prefer a table or meta-test
  that fails when a family or boundary is added without its row. (Evidence:
  §5.11's entitlement miss — two of three siblings handled at every boundary, the
  third identically named and skipped at all of them.)
- Special case worth memorizing: when the update is computed as a delta between two
  snapshots, the delta must be complete over the domain's symmetry — whatever you do
  for "present now, absent before," consciously decide for "absent now, present
  before." Removal is the classically-forgotten mutation, because fixtures grow but
  rarely shrink.
- The same discipline applies to **dynamic state, not just input parameters**: for a
  stateful object (work queue, action stack, state machine), enumerate
  (state × event) and account for every transition — with "aborted",
  "mid-checkpoint", and "resumed" included as states. The fan-out branch's
  atomicity family (parent cursor advanced before child admission could fail;
  completion marker set before the work it records committed; abort path still
  committing state) all lived in transition cells nobody had written down.
- House style to aspire to: the ingest-invariants verdict table — "a policy hole is a
  missing row, not a missing if-branch." Small space → explicit dispatch table in
  code. Combinatorial space → generate it (that's what fuzzing is: mechanized
  permutation coverage). Neither → the PR states the dimensions and disposes of each
  cell.
- **Where the table lives**: cells this repo can execute become rows of one
  table-driven test — the expected value *is* the outcome, and excluded cells
  are skipped rows with a reason string, so the table cannot drift from behavior.
  Cells that require an artifact this repo cannot execute (an older SDK's
  behavior) become a comment on the boundary itself — where the next editor of the
  format will be looking — and migrate to the two-artifact harness when it
  exists. The PR description only *points* at both: nobody rereads a merged PR,
  and the table is needed by whoever touches the format next.
- **Design corollary: do not create state spaces too large to test.** Every
  independent boolean option, mode flag, and capability interface multiplies the
  cross-product. If the space can't be enumerated or fuzzed, the design is wrong, not
  the test plan.

### Pass 4: Error handling, classification & budgets

Every error lands in a declared category (retryable / decline-to-slow-path / fatal /
warn-and-skip), and each category's recovery obligation is discharged (e.g., restore
store state before falling back). Additionally:

- **Trace every deadline-bearing context to the work it bounds.** "A deadline exists
  but the inner work uses a different context" is a proven recurring class here
  (#899, #891, #893, the incremental branch's sidecar persist — and two more on the
  fan-out branch: a discarded timeout context in the skip-sync path, and a run
  duration that never reached root planner I/O).
- **Error identity is part of the contract:** status codes and sentinel matches must
  survive every wrap/remap boundary between the producer and the classifier that
  acts on them (§5.3, classification is a contract).
- No deferred `Close`/`Sync` may swallow errors on a success path (#811: torn
  artifacts reported as success).
- Retried operations must make durable forward progress in units smaller than the
  retry budget, or interruption livelocks (#911: unbounded DELETE vs. deadline, prod
  stuck 1h+).
- Watch for silent degradation: a fallback that always fires is a dead feature with
  green tests.
- A declared error category no test can *cause* is dead code with a taxonomy:
  fault-inject each category at the site that produces it and assert the recovery
  obligation is actually discharged (§5.10).

### Pass 5: Invariant & verification gating

Any code that writes rows is an ingestion path and must pass through the invariant
gate (`RunIngestInvariants` + verification marker; the code calls this the invariant
pass). New write paths that bypass the syncer are guilty until proven registered.
Artifacts must satisfy their self-description: sidecar sync IDs match the sync-run
record, verification markers current, graphs marked expanded, format versions valid.
(This review pass polices that gate; §5.9 is why it exists and where it must sit.)

### Pass 6: Performance

Per-checkpoint / per-iteration fixed cost at whale scale (100k entitlements, MB-scale
graphs). What does the *failure* path cost? (A declined/fallback attempt is pure
overhead — it must be cheap.) Serialization in loops is the repo's recurring sin: the
sync token re-marshals everything embedded in state every ~10 seconds for the sync's
lifetime. Session-store access inside per-resource/per-grant loops is a network storm
in prod (§5.6).

When the current stage changes executed work on a cost-contract path (§2: expansion,
compaction, per-checkpoint loop, artifact-open-time work), this pass has a
deliverable, not just a look: state the cost-curve delta in
grants/entitlements/graph size, and point at the benchmark that enforces it. For a
stage with no runtime or cost-curve change, record that outcome; no benchmark is
required.

Inventory every operation that walks the affected domain, not only the feature's
headline path. A bounded replay implementation does not establish bounded-memory
behavior if replacement, tombstones, cleanup, or retry scans still build O(scope
size) batches.

### Pass 7: Concurrency

Check-then-act (TOCTOU) on anything shared (#812). Concurrent writers to the same
artifact — lambda retries mean the same task may run twice, possibly simultaneously;
conflict winners must not depend on which replica was slower. Goroutine lifecycle:
panics recovered in background goroutines (#845), error returns structured so defers
actually run (#854). Remember §2: this pass finds *logic* concurrency bugs; the data
races are the race detector's job, not yours.

## 4. The systematic-solutions ladder

When a bug is found, don't just fix it — climb as high on this ladder as is
proportionate. (Whatever the rung, the resulting instrument must itself pass §2's
validation: premise proven, oracle shown to fail on a planted violation.)

1. **Type system / API shape** (best): make the invalid state unrepresentable.
   - Capability interfaces over type assertions — but note assertions on *optional*
     capabilities fail silently forever after a rename (#774). Every implementation
     needs a compile-time check (`var _ Iface = (*Impl)(nil)`) or a test that the
     production store satisfies it.
   - Explicit version/generation fields in opaque durable envelopes whose semantics
     can change independently of their wire shape, with both obligations that make
     the field real: **writers bump** on a reader-visible semantic reinterpretation,
     and **readers fail closed** on unknown versions — degrading to redone work,
     never a silent partial parse. Standard protobuf messages follow protobuf
     compatibility rules; an additive field does not require a parallel semantic
     version unless its absence changes correctness. Evidence: the cross-version
     data-loss bug shipped *with* a version field present; nobody bumped it, and JSON
     zero-fill parsed the new fields away without error.
   - A single stored-state descriptor (key range + cleanup policy declared once) that
     all cleanup paths iterate, making "forgot to register" impossible rather than
     greppable.
   - Sealed-state types that can't be written; constructors that force the invariant
     pass.
   - Secrets get a wrapper type that redacts on `String()`/`Format()` at the boundary
     where they enter. Direct logging of secrets is ordinary review's job; the type is
     for the *indirect* flow — a third-party parse error echoing secret-bearing input
     into a wrapped error that lands in a durable artifact (log, token, checkpoint).
     Where third-party errors wrap secret input, add one
     `NotContains(err.Error(), secret)` test — upstream error content is not ours to
     control (age branch tests exactly this wrap).
2. **Fuzzing / property tests with an oracle.** This repo is rich in free oracles:
   incremental vs. full recomputation, marshal/unmarshal round-trips (including
   converters — #997 dropped a field in toPebble), retry-twice-converges idempotency.
   Differential testing beats hand-written cases when the space is combinatorial.
   (Pebble-vs-SQLite equivalence is a *sunsetting* oracle: keep existing tests while
   both engines live; build nothing new on it.)
   - **The stateful form — an executable reference model — is the instrument for
     lifecycle interleavings.** A small model (maps plus explicit
     dirty/close/reopen/crash semantics) is the oracle; randomized operation
     sequences interleaving mutations with close, reopen, and injected faults are
     the generator; shrinking makes failures readable. This machine-discovers the
     class reading keeps finding by hand — convention-coupled state across
     lifecycle boundaries (§5.11, dirty-vs-Close races) — because the model owns
     the lifecycle semantics directed tests never enumerate. Keep the model
     maintained with the subsystem (§2: the harness is part of the subsystem).
     External existence proof: Amazon S3's ShardStore validated an LSM storage
     node exactly this way, run by ordinary engineers, not specialists.
3. **One validator over many point tests, when production owns the invariant.** A
   validator needs a stable production call path and an actual caller; do not add an
   unused runtime validator to a schema-only stage. An artifact fsck — sealed-c1z
   self-description checked at the end of every producing test — retires a bug
   *category*. Include a leak check: every key/record in a store is owned by the live
   sync or explicitly allowlisted. Cheap variant: run the suite once with the noop
   session store; any failure is a source-of-truth violation hiding in the cache
   layer. When no production call path exists yet, use a test-only oracle or defer the
   runtime obligation to the stage that introduces its owner.
   - **Ride-along variant when the test fixture owns the invariant**: bind the
     checker to a shared fixture or choke point so every existing test evaluates
     it for free — a resource-leak counter at the rawdb choke point asserted at
     engine close; a proof-flag/keyspace consistency check after a test's
     mutations. Hardware embeds assertions in the design and evaluates them in
     every simulation; sanitizers are the software equivalent. The multiplier is
     the point: the sync-replay closer leaks sat on error paths whose
     fault-injection tests already existed — the missing half was the oracle. A
     ride-along converts every present and future test into a detector for the
     class, at zero per-test cost to authors.
   - **Positive-evidence variant for completeness** (the absence class from §2): an
     evidence set maintained at the state-mutation funnels — enroll on admission,
     delete only on legitimate completion, rebuild from the checkpoint on resume —
     reconciled at quiesce. Absence bugs produce *missing* rows with perfect
     referential integrity; only positive evidence of completion can see them
     (the fan-out branch's spawned-cursor drain invariant — not yet on main;
     main ships I1–I9 in `pkg/sync/ingest_invariants.go`). The stronger form is a full
     ledger: `sealed = received − deliberately_dropped + generated`, every term of
     which the SDK can count — a mismatch is attributable to the SDK by
     construction.
4. **Integration tests** that exercise the real store/engine lifecycle — resume, seal,
   fold, *reuse* — not mocks. Single-sync fresh-store tests are structurally blind to
   the orphan class.
5. **Unit tests** for logic-dense pure functions. They are the right-sized instrument
   for local logic, but cannot by themselves establish lifecycle, cross-artifact, or
   deployment-boundary properties.

## 5. Bug patterns, organized by principle (the "we've been burned" list)

Each family is a **general principle** with the local evidence that earned it a slot.
The principle is the reusable part — apply it to code the evidence never touched.
When adding an entry, first try to file it under an existing principle; a new
principle needs at least a plausible second instance.

### 5.1 Durable claims are ordered after the facts they claim

A durable record asserting work *happened* must be written after the work is durably
done. (Records of *intent* may be written before — that's a write-ahead log. Never
confuse the two directions.)

- Completion flag written before the work it records was durably scheduled: any
  intervening error becomes a permanent skip (fan-out branch, `TypeScopedPlanned`).
- Graph sidecar fsync'd before the sync seals: it describes data a resume is free to
  rewrite (incremental branch).
- Success reported before the OS flushed the artifact: deferred `Close` swallows
  write-back errors (#811). Explicit Sync+Close+err-check on success paths.

### 5.2 Every exit path discharges the same obligations

Enumerate the exits — success, error, abort/cancel, panic — and verify each leaves
the same postconditions. Cancellation is an event that gets its own cell in Pass 3's
(state × event) table; it is the one nobody writes down.

- Abort path that still commits state, bypassing the dedup set and caps the normal
  path enforces (fan-out branch).
- Validate everything, then mutate: a parent cursor advanced before sibling
  admission could fail silently drops the rejected cursors on resume (fan-out
  branch). All-or-nothing commit; a validation failure leaves prior state untouched.
- Error returns structured so deferred cleanup actually runs (#854); panics
  recovered in background goroutines (#845).
- Closing or releasing a pooled object transfers ownership. Clear or replace every
  retained pointer immediately, make deferred cleanup nil-safe, and assert the
  ownership state directly. A second `Close` that usually returns `ErrClosed` can
  become a cross-goroutine race after the pool reissues the object.
  Capture the quality mechanically: record acquire/transfer/release and all exits in
  the implementation-obligation addendum; prefer a lexical helper that owns the
  closer around a callback; inject failure after acquisition; and require active
  resource counts to return to baseline. For pooled objects, assert the retained
  pointer is nil immediately after release.

### 5.3 Classification is a contract: explicit, total, preserved, coherent

Wherever behavior branches on the class or identity of a value — an error's
retryability, a cursor's identity, a record's kind, a store's capability — that
classification must be **explicit** (a dedicated field, never an in-band magic
value), **total** (closed over every producer of the domain, including implicit
ones), **preserved across boundaries** (wraps, RPC hops, and serialization must not strip
the status/sentinel identity downstream classifiers act on), and **coherent** (two
classifiers over one domain state their intended relationship, asserted in a test).

- Explicit: inferring "type-scoped" from `ResourceID == ""` misrouted
  malformed-but-real stored rows into the new behavior (fan-out branch).
- Total: a dedup identity that enumerated "the kinds of cursor" missed the implicit
  one — the parent's own continuation token collided with a spawned sibling's
  (fan-out branch). Same failure at the API level: `Pick` on annotations silently
  collapses N>1 to one; count before picking where multiplicity matters.
- Preserved: a host-side wrapper string-matched `err.Error()` and returned a fresh
  error, stripping the gRPC status — retryable lambda timeouts became
  non-retryable, discarding hours of checkpoint progress ~1,100×/fortnight (timeout
  effort; visible only by tracing the value across the repo boundary).
  `strings.Contains(err.Error(), ...)` gates are findings by default; a rewrap
  preserves status/sentinels or explicitly declares the downgrade, enforced by a
  consumer-side test.
- Coherent: `retry.go` held `DeadlineExceeded` retryable while `IsSyncPreservable`
  refused to preserve it — incoherent without reading either body. State the
  relation (retryable ⊆ preservable) and assert it (timeout effort).
- Type assertions are classifications too: an optional-capability assertion fails
  silently forever after a rename (#774: months). Compile-time
  `var _ Iface = (*Impl)(nil)` per implementation.
- Result counts are classifications, not mutation evidence. `Rows == 0` does not
  imply no durable write when an operation may replace, delete, clean, or commit a
  prefix before failing. Mutating APIs should return explicit mutation information
  (for example copied/deleted/committed counts plus `Mutated`) or conservatively
  mark persistence dirty whenever any invoked path may have committed. Verification
  independently compares the reported mutation status with before/after state.
- Drift-prone shape: `(bool, error)` returns with sentinel taxonomies — callers
  reconstruct outcomes wrong. Prefer typed results.

### 5.4 Stored state has a lifecycle contract; registration must be structural

Every keyspace, sidecar, and record type must be handled by *every* lifecycle
surface — cleanup, reset-for-new-sync, fold rewrite-or-delete, format conversion.
Convention-maintained registries are independently forgettable; the structural fix
is one stored-state descriptor that all surfaces iterate (§4 rung 1).

- Orphaned records after syncs: broken prod repeatedly, never reproduces locally —
  fresh-store single-sync tests are structurally blind. New stored state needs a
  reuse-lifecycle test (sync → sync again / reset / fold / resume; assert nothing
  keyed to the first sync survives).
- Copied artifacts inherit metadata keyed to the source sync: fold/copy must rewrite
  or delete every such sidecar/marker (stats, invariant marker, graph — the graph
  was the miss on the incremental branch).
- The inverse failure — convert/copy paths *lose* fields: converters must be closed
  over the full record schema, enforced by round-trip equivalence (#997: toPebble
  dropped `discovered_at`; recurred in #1023: resources dropped
  `profile`/`status`/`created_at` — the class jumps between record types). The
  instrument, still unbuilt: one test over every (v2 message, v3 record) converter
  pair that populates *every* field via `protoreflect` (a hand-written fixture is a
  point test that rots), round-trips, and requires each field to survive or appear
  on an exemption list with a stated reason. The proto descriptor is a free
  coverage model; this is closure over it.
- The syncer is not the only writer: resume-and-write compactor paths bypass every
  side effect attached to the syncer (invariants, markers, cleanup).

### 5.5 Bytes crossing a boundary are hostile

Opaque durable formats whose meaning can change across a process, version, or
service boundary need an explicit semantic version, a fail-closed reader, and a
round-trip test. Standard protobuf evolution uses its own compatibility contract:
lint/breaking checks and unknown-field-safe additive changes. Add an envelope version
only when wire compatibility alone cannot preserve meaning.

- Go JSON zero-fills silently: unversioned structs parse wrong data after a rename —
  and versioned ones parse *new fields* away just as silently unless writers bump
  and readers fail closed (§4 rung 1: the rollback data-loss bug happened *with* a
  version field present).
- Session values cross process/version boundaries through a service: version
  envelopes, tolerate absence, never trust shape.
- Cursors must be self-contained: a page token encodes everything a cold-started
  process needs; the connector doesn't "remember."
- Once producer and consumer implementations exist in one module, a shared
  executable convention should normally have one owner both sides call, collapsing
  the contract to "call this" — greppable, and it cannot drift. Do not create that
  owner speculatively in a schema-only stage. (Age branch: `key_ids =
  hex(sha256(recipient))` lives in a proto comment while the consumer imports this
  repo.) Prose remains appropriate for staged contracts and boundaries where code cannot
  be shared.

### 5.6 Distribution invalidates local intuitions

Applications of §1's corollaries — the local topology (parent process, one machine,
sticky everything) systematically hides these.

- No sticky routing → no cross-boundary caching: memoizing within one invocation is
  fine; any map that outlives one operation is suspect.
- Session-store calls are RPCs, not map reads: per-key lookups in hot loops are a
  prod network storm; batch, and give session errors a declared category (the local
  transport almost never fails, so error paths are untested by default — §5.10 is
  the systematic answer).
- No read-your-writes across task boundaries: the noop and memory session
  implementations legally return nothing; session data is a hint that may be
  absent. Correctness-critical state lives in the token or the c1z.
- The same task may run twice, possibly concurrently: idempotency-by-identity on
  every write path; conflict winners must not depend on replica speed.
- Clock skew feeds newer-wins merges: `discovered_at` comparisons cross machines;
  distrust wall-clock ordering across process boundaries.

### 5.7 Budgets bound work only if the plumbing connects them

A declared limit (deadline, retry budget, checkpoint interval) constrains nothing by
existing; trace the connection from the declaration to the work it is supposed to
bound.

- Dangling deadlines: a deadline-bearing context exists but the inner work runs
  under a different one (#899, #891, #893, incremental sidecar persist, fan-out
  skip-sync and root-planner paths). Trace the plumbing, not the declaration.
- Retry-granularity livelock: work units bigger than the retry deadline make zero
  forward progress under repeated interruption (#911: prod cleanup stuck 1h+).
  Batch with durable commits so each attempt advances. Migrations are the worst
  case (§2's intersection class): an open-time migration whose cost curve exceeds
  the budget at whale scale retries the same artifact into a permanent every-sync
  failure — chunked and resumable is mandatory, not an optimization. (Evidence:
  the grant migration that failed every sync in prod on big-O grounds.)
- Marshal-in-checkpoint-loop: anything embedded in sync state is re-serialized
  every ~10 seconds for the sync's lifetime; per-checkpoint cost is a budget nobody
  declared.

### 5.8 Unfinished transitions rot into hazards

Any "temporary" dual state — a rollout flag, a deprecated engine, an aging branch —
is a standing bug source carrying a finish-or-delete obligation. Silence is the
common thread: each of these fails by *nothing happening*.

- Feature-flag rot is the dual of "a fallback that always fires": a gate that never
  graduates is dead code with a confusing name (`SYNC_PRESERVABLE_C1Z`, a *host-side*
  gate — not greppable in this repo: off for
  99.2% of the events it governed; the stale gate repeatedly derailed the timeout
  investigation). Every flag carries graduation-or-delete, and each long-lived flag
  doubles Pass 3's state space.
- Deprecated-engine rot cuts both ways: SQLite fallback paths decay untested but
  stay required until removal ships. Touching a dual-engine path: verify the
  SQLite path or explicitly gate it off. The capability interfaces and
  degrade-to-token dualities are the removal-day cleanup checklist.
- In exported library API the transition may be *unfinishable*: deprecated symbols
  can be aliased, never deleted. The standard is old name = thin delegate to the new
  path — never a parallel implementation — with the equivalence asserted in a test.
  (Age branch: two registries and two resolvers over one config type, nothing pinning
  them coherent; §5.3's coherence clause applies doubly when the dual state is
  permanent.)
- Branch aging: a conflict-free rebase can be semantically stale — review the
  *rebased* semantics against current main (the incremental branch predated the
  invariant gate entirely).

### 5.9 An obligation owned by every path is owned by none — localize it

When a cross-cutting obligation (validation, derived rows, cleanup, markers) is
implemented per-path, paths drift, readers make path-dependent assumptions, and new
paths silently omit it. The coupling is unmarked — nothing tells the author of path
N+1 what it must replicate — so review is the only enforcement, and review has no
closure criterion (§2). This is the design-side principle behind Pass 5, §5.4's "the syncer
is not the only writer," and the stored-state descriptor (§4 rung 1). Two
escalating fixes, both used in this repo:

- **Funnel the paths**: force all writers through one choke point and implement the
  obligation once on the shared path (Phase 2, #1016 — the rawdb choke point: a new
  path has no way in except through it).
- **Re-derive the obligation from state, not events**: redefine it as a function of
  the *resulting* state, evaluated once at a terminal check, making it independent of
  how the state arrived (Phase 3, #1017 — ingest invariants: "each side effect is
  defined as a function of the store and evaluated after every writer has
  finished"). Stronger than the funnel: it severs the event coupling instead of
  centralizing it.

The caveat that bit anyway: **the check must sit at the true convergence point.**
Phase 3 attached evaluation to the syncer, but the syncer is a client of the store,
not its funnel — the compactor's resume-and-write path bypassed the syncer while
still reaching the sealed artifact (incremental branch). The point nothing can avoid
is the store's seal; anything shallower is a funnel with a gap.

Costs to accept knowingly: a post-hoc scan instead of piggybacking on the write (I4
became fail-fast-only for exactly this reason); *detection* is late — fine for
validation, wrong for anything that must be *prevented*; and per-row provenance the
check needs must be recorded in the data (exemption annotations), because the call
stack that knew it is gone.

### 5.10 The environment is an input — sweep it like one

Ordinary tests hold the environment implicitly cooperative, so every error path is
dead code until a fault injector executes it. Treat the fault schedule as a test
dimension and apply Pass 3's coverage doctrine to it: exhaustive over a stated
window, seeded-random over the combinatorial rest. House exemplar: the engine
errorfs sweep (#1015; `pkg/dotc1z/engine/pebble/errorfs_sweep_test.go`).

- **Contract first.** Injection without a stated recovery contract is chaos, not
  verification. The sweep's oracle — any injected failure followed by a crash must
  reopen as resumable-unfinished or finished-and-content-complete; anything else is
  a durability-ordering bug by definition — is what converts injected faults into
  findings. The injector supplies adversarial schedules; the oracle judges them;
  neither is useful alone.
- **Model the deployment's physics, not what's easy to inject.** A dying disk does
  not recover: fail the k-th write *and all subsequent*, or post-failure background
  writes heal the crash image. A crash keeps only fsynced data (strictest image). A
  storage-engine fatal is a wedged process, observed from outside — not recovered
  in-process. Lambdas die mid-task and run the same task twice. A fault model
  gentler than production tests faults that do not occur — and some production
  faults are invisible to local physics entirely: a Lambda freeze pauses the
  monotonic clock, so `IdleConnTimeout` never sees the gap while proxies time
  pooled connections out on the wall clock (#1005 — the fix measures the gap in
  wall-clock time, and its tests count connections to prove the pool was dropped).
- **Injection points are a design requirement.** Injection reaches only what flows through an
  interface (pebble vfs, session store, connector RPCs, contexts/clocks). Raw
  `os.*` IO is outside every fault domain — the sweep's own stated exclusion (the
  v3 envelope save) is an untested error path by construction. State exclusions
  explicitly; each one is a finding-in-waiting, and new IO should route through an
  injectable hook rather than enlarge the exclusion list.
- **Completeness must be provable.** The sweep arms at EndSync and raises k until
  an armed run completes without injecting anything — positive evidence the window
  was covered end-to-end. Prefer that shape over "we injected some faults."
- **Prove the instrument can see its faults** (DV's mutation adequacy): plant a
  known contract violation and watch the harness fail. A sweep that has never
  caught a planted bug is itself unverified code.
- **Enumerate injection points mechanically, not from memory.** A hand-maintained
  hook registry drifts exactly like §5.4's convention registries: the next commit
  loop ships without a hook and its error path is dead code again. Prefer a
  meta-test that derives the commit/write call sites from the code (AST scan or
  choke-point registration) and fails when one lacks a registered hook and a
  failure-obligation test — the house idiom is `seamFailureCases` +
  `TestSeamsArmedOnlyInTests` in the pebble engine; SQLite's
  OOM-injection-at-every-allocation is the fully generalized form.
- Latency and deadline expiry are faults too: injecting them is the instrument for
  §5.7's dangling-deadline class — a budget no test can cause to fire bounds
  nothing.

### 5.11 Derived state is a proof; every falsifying transition must invalidate it

A cache, fast-path flag, or precomputed index (`keyspace_is_empty`, `skip_get`, a
bare-id lookup map) is a stored claim about other state. It authorizes skipping
work only while its premise holds. The failure mode when it goes stale is §2's
worst cell — the next writer skips required reads or cleanup and produces
well-formed wrong durable rows, silently.

- Inventory the transitions that establish, consume, or falsify each proof from
  the implementation's actual state machine, not from memory of the intended
  lifecycle — fresh starts and resumes, bulk paths, resets, replays, and partial
  failures all count if they can falsify the premise. Cross the inventory with
  every sibling family that carries its own copy of the proof (Pass 3).
- Invalidate at the falsifying commit, or conservatively before entering the
  mutating boundary — never only in success-path code after a helper returns. A
  failure that committed a prefix has already falsified the premise.
- Durable key/value auditors cannot see a stale in-memory proof, so reopen-and-
  inspect evidence is blind to this class. The oracle is a colliding write whose
  correctness requires the slow path, issued after each falsifying transition,
  with a premise assertion that the proof was armed beforehand — without that,
  the test passes vacuously.
- Evidence (sync-replay): grants and resources disarmed their empty-keyspace
  proof at sync bind and bulk-import finish; entitlements — same field group,
  same naming — did not, and a replay clear that failed after a committed batch
  left the proof armed for all three kinds. All three misses survived the frozen
  plan, its instruments, and two independent audits, and fell to a targeted
  implementation read; the colliding-write oracle then reproduced each in one
  round. The entitlement bare-id lookup map's write-invalidation is the same
  class one layer up.

### 5.12 A commit point is a contract — six answers per site

A commit point is where staged work becomes durable: the one place where what
the code believes and what the disk holds can split. It is where the sibling
principles above concentrate, so audit each site against all six at once
rather than rediscovering them one bug at a time. Every commit call site owes:

1. **An executable failure.** Some instrument forces THIS commit to fail and
   observes the aftermath. Each distinct commit loop is its own cut — a hook
   on a sibling loop proves nothing here (§5.10; enforced mechanically by the
   pebble engine's commit-point registry meta-test, which fails when a commit
   site ships without a hook route or a written exclusion).
2. **Failure re-converges derived state.** The batch is atomic; the flags,
   proofs, markers, and caches ABOUT the keyspace are not. A failed commit
   must invalidate every proof it may have falsified (§5.11).
3. **Success reaches the checkpoint.** The dirty transition and the engine
   mutation are one atom with respect to a concurrent Close; zero-result and
   no-mutation are different facts and must not be conflated (§5.1, §5.11
   evidence: replay marking dirty only on `Rows > 0`, orphan healing reporting
   zero and being discarded at Close).
4. **Partial progress is accounted and retryable.** Multi-chunk loops report
   the committed prefix on error, and a retry over that prefix converges
   without double-applying or skipping (Pass 2; the committed-prefix-retry
   harness pins representative cuts).
5. **The batch is released exactly once on every path** — success, failure,
   early return (§5.2; enforced globally by the rawdb outstanding-batch ledger
   asserted at Close. Evidence: the compactor's overlay flush committed and
   re-minted without closing, leaking two pooled batches per flush for the
   life of the fold path; the ledger found it on its first full-suite run).
6. **The durability class is justified.** Every `NoSync` is correct only
   because a named downstream fence (checkpoint, envelope save, WAL sync
   point) fsyncs before anything depends on the write. This is the one
   obligation on this list with no mechanical check — the justification lives
   in comments at each site, and the in-process error hooks are only a proxy
   for the real event (a crash between the halves of an ordering contract),
   which the errorfs sweep and crash-reopen tests carry for the paths they
   visit.

## 6. Process guidance for AI-driven review

- The operational index lives in `docs/REVIEW_CHECKLIST.md`: the routing rule,
  the step-up pipeline, the pass and ladder lists, and the principle index on
  one page. Load it in every review conversation and consult this handbook by
  section (the slice map below). The checklist is derived, never authoritative.
- For step-up changes, use this sequence: frozen behavioral plan →
  implementation-obligation addendum → instruments → mutation adequacy → execution
  → structural-coverage triage → independent evidence audit → focused
  implementation review → repository gates → signoff.
- Keep the machinery proportional. The full closure packet and independent audit
  are step-up controls, not requirements for a local low-risk fix. Prefer ordinary
  Markdown, table-driven tests, and existing repository commands over a new
  verification framework.
- Route first (§2): review is one instrument among several, and its budget is two to
  three rounds. Multi-artifact, schedule, absence, and error-path risks get
  harnesses, not more reviewers.
- For a step-up change, enforce §2's draft-PR-before-implementation rule and require
  criterion-to-instrument-to-evidence traceability before merge. For a staged plan,
  first separate criteria due now from criteria whose executable subject arrives in
  a named later stage. Check that each current-stage artifact exists, asserts the
  stated criterion, ran successfully, and supports the claimed coverage level.
  Report an unmapped current-stage criterion as a blocking or confidence-limiting
  gap; do not demand speculative implementation for a genuinely deferred
  criterion. A plan reconstructed from the finished diff is not preregistration.
- Final signoff uses the repository's documented commands: lint,
  generation/compatibility checks when applicable, targeted tests, required race
  runs, and the broad regression suite. IDE diagnostics are supplemental; they do
  not replace repository lint.
- **Structural-coverage triage** (step-up changes, after instruments run): produce
  a coverage profile over the changed packages and disposition every uncovered
  branch in *changed* code as dead code (delete it), a missing obligation (extend
  the addendum), or a missing instrument. Coverage is a gap detector, never a
  target — the percentage proves nothing, but an uncovered changed branch is by
  construction one of those three findings. (DO-178C's structural-coverage
  analysis exists to catch exactly this class; the stale fast-path proofs and
  dirty-marking misses all lived in branches no instrument executed.)
- Before signoff, a reviewer independent of the instrument author audits every
  **verified** closure entry against the frozen wording and implementation: confirm
  the required instrument exists; name the exact premise and oracle assertions,
  layer, instantiated dimensions, applicable close/reopen evidence, the shared or
  criterion-local representative planted violation when required, and whether
  coverage is exhaustive, reduced, or sampled. Grouped criterion ranges, test names,
  comments, and key counts standing in for content integrity are not evidence.
  Downgrade the status rather than rationalizing a weaker test after the fact.
- If the change touches a subsystem meeting §2's silent/combinatorial/no-oracle
  criterion, ask for the property list and the verification harness — their absence
  is the finding. Do not accept review rounds as a substitute; no number of them
  constitutes coverage there.
- Run the **selected** passes independently. For HIGH changes receiving the full
  pass set, parallel separately-prompted agents across different models provide
  useful decorrelation; narrow stages may combine closely related passes when their
  risk assessment is recorded. Each reviewer reads the surrounding unchanged code
  (not just the diff), cites file:line, and discards anything unverifiable. Then
  **verify every finding against the code before accepting it** — severity
  re-grading in both directions is normal.
- Verification does not replace focused implementation review. After instruments
  pass, a reader decorrelated from both the implementer and the instrument author
  reviews the implementation-obligation addendum's material: resource lifetime,
  error exits, ownership transfer, result/mutation mismatches, derived fast-path
  state (§5.11), and local hazards the behavioral oracle does not observe. Signoff
  requires this read to yield zero new highs. A finding is a cheap falsification
  of the closure claim, not merely a bug: affected criteria return to evidence
  incomplete, the finding's class climbs the §4 ladder (recurrence rule), and the
  read repeats on the fixed code — the review budget is per change order, because
  each fix is new code with fresh hazards. A clean read is necessary, never
  sufficient: it measures the reader as much as the code (§2's stopping rule;
  the fan-out worst bug survived five rounds that named its scenario), so it
  falsifies closure claims but never substitutes for coverage. (Evidence:
  sync-replay — closure was declared three times and a decorrelated
  implementation read produced new highs each time; every finding was
  addendum-class material no behavioral criterion could name.)
- **Slice this document when spawning pass agents; do not paste it whole.** Pass
  agents receive no context except their prompt, so the orchestrator inlines the
  relevant sections verbatim. Feeding all ~50 checkable items to every agent
  dilutes the ones it owns. The map (§1 goes to everyone; add §7 if the slice
  cites effort shorthand):
  - Pass 1 (edge cases): §1 + Pass 1 + §5.3
  - Pass 2 (checkpoint/resume): §1 + Pass 2 + §5.1, §5.4, §5.5, §5.11
  - Pass 3 (permutations): §1 + Pass 3 + §5.2, §5.3, §5.11
  - Pass 4 (errors/budgets): §1 + Pass 4 + §5.3, §5.7, §5.10
  - Pass 5 (invariant gating): §1 + Pass 5 + §5.9
  - Pass 6 (performance): §1 + Pass 6 + §5.6, §5.7
  - Pass 7 (concurrency): §1 + Pass 7 + §5.6
  - Fix-time agent: §4 + this section's failing-test-first and recurrence rules
  - Orchestrator (you): the whole document, read once.
  A consequence: mild redundancy across sections is required — sliced readers
  never see the other copies. Do not deduplicate it away.
- Check merge-base age first; review what the change means on *current* main. Also
  confirm `git log base..head` contains exactly the intended commits before spending
  review budget: a worktree branched from a dirty local HEAD shipped foreign commits
  into a PR, and reviewers produced confident findings about code nobody under
  review wrote (timeout effort).
- When vendored or dependency changes dominate the diff, verify provenance
  mechanically before reviewing the rest: the version is a tagged upstream release,
  `go mod verify` passes, and every *new* transitive dependency — especially
  cryptographic — is named in the PR description with a reason. A 3,000-line vendor
  diff nobody mentions is a finding (age branch: ~75% of the diff was a vendored age
  upgrade pulling in new post-quantum primitives).
- **Failing evidence first** for every confirmed bug when a practical executable
  reproducer exists: write the test, watch it fail for the right reason, then fix.
  Schema, documentation, generation, and build defects may instead use the
  corresponding lint, compatibility check, static reproducer, or generated diff;
  record why a runtime regression test is not the right instrument. (Empirically
  required on the fan-out branch: fix rounds stopped regressing when test-first
  became mandatory for its runtime bugs.)
- Contracts check on any exported API touched: doc comments match actual behavior;
  functions whose names promise purity (Marshal, Get, Read) don't mutate arguments.
  For proto contracts, map every behavioral sentence implemented or relied on in
  the current stage to the test that would fail if it were false. In a schema-only
  stage, require schema evidence and record runtime semantics against the first
  producer/consumer stage; do not invent an unused runtime validator.
- End reviews with: a coverage-vs-gap table, a confidence statement, and — for each
  finding — which rung of the §4 ladder would have caught it mechanically. If a
  finding has no mechanical catcher, that's a gap in this document: add it.
- **The recurrence rule** (dual of the above): when a bug belongs to a class this
  document already names, the fix must ship the ladder climb, not just the patch —
  point-fixing a documented class is itself a finding. Evidence: converter field
  loss was point-fixed in #997 (grants, `discovered_at`); the class recurred 19
  days later in #1023 (resources, `profile`/`status`/`created_at`) and was
  point-fixed again; the descriptor-closure test that retires the class still does
  not exist (§5.4).
- **This document has a growth budget.** It teaches stopping rules and gets one
  itself. A new lesson first merges into the principle it instantiates —
  strengthening the rule or replacing a weaker example — and may open a new
  subsection only for a class no existing principle covers (§5's intro states
  the same rule locally). When a lesson repeats §2 policy, tighten the existing
  bullet rather than appending a sibling; prefer displacing the weakest example
  over adding a fourth. Any change to the pipeline, the pass list, the ladder,
  or the principle list updates `docs/REVIEW_CHECKLIST.md` in the same commit.

## 7. Case-name index

Evidence bullets cite recurring efforts by shorthand. PR numbers resolve with
`git log --grep`; branch refs age out, so the descriptions are the durable part.

- **Incremental branch** — `manoj/incremental-grant-expansion` (unmerged at time of
  writing): diff-aware grant expansion with a persisted graph sidecar. Source of
  the sidecar-ordering, graph-copy, and compactor-bypass evidence.
- **Fan-out / type-scoped branch** — the type-scoped sync fan-out effort (parallel
  per-resource-type cursors spawned from a parent; unmerged at time of writing).
  5 adversarial review rounds, ~18 confirmed bugs; source of the atomicity-family,
  absence, and dedup-identity evidence — and of the worst bug on record, the
  cross-version checkpoint resume that silently sealed an incomplete sync.
- **Timeout effort** — lambda-timeout preservability work spanning this repo and
  the c1 host: retryable-timeout classification, preservable sync state, and the
  host-side rewrap that stripped gRPC status. Source of the cross-repo boundary
  evidence; its contract tests live on the consumer side.
- **Sync-replay effort** — multi-model implementation-blind plan synthesis broadened
  the coverage model before freeze; repeated implementation review still supplied
  no measurable closure. Verification instruments then found durable contract
  defects and exposed the need to distinguish "criterion accounted for" from
  "verified to stated coverage." A later independent plan-to-test audit found that
  grouped criterion ranges hid a missing reconciler, weaker-than-planned oracles,
  uncovered cross-product cells, layer mismatches, and a vacuously passing rejection
  test—evidence for criterion-local closure entries and premise validation. After
  closure was declared, a targeted implementation read found three stale
  fast-path-proof misses that plan, instruments, and both audits had passed over —
  the evidence behind §5.11. The closing instrument round (resource-leak ledger,
  reference-model soak, commit-point registry, structural-coverage triage) then
  found a compactor batch leak, silent since the overlay writer shipped, on its
  first full-suite run, and two
  leave-it-alone gaps (replay overwrite index cleanup, scoped tombstone
  survivors) that 40+ directed verification tests had missed — the evidence
  behind §5.12 and the §6 triage step.
- **Age branch** — `paul.querna/age-recipient-encryption`, merged as #1021: age
  recipient encryption provider. The small-stateless counter-case: most passes
  route to N/A and the residual risk is all at repo boundaries.
- **Phases** — the verification-infrastructure PR series: #1015 (Phase 1, pebble
  fault-injection harness), #1016 (Phase 2, rawdb choke point), #1017 (Phase 3,
  ingestion invariants I1–I9), #1022 (Phase 4, source-cache replay protos).
- **The c1z spec break** — a format change that old SDKs could not read, forcing a
  new SDK version and a compatibility matrix stood up after the fact. §2's
  remediation-rung-4 exemplar: the cost was coordination, not the code fix.
- **The grant migration** — an open-time migration whose big-O was fine at fixture
  scale and over budget at whale scale; it retried the same artifact and failed
  every sync in prod. §2's intersection-class exemplar (same livelock shape as
  #911).
