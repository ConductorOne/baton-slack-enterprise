package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/grpc-ecosystem/go-grpc-middleware/logging/zap/ctxzap"
	"github.com/spf13/cobra"
	"go.uber.org/zap"

	"github.com/conductorone/baton-sdk/pkg/c1zsanitize"
	"github.com/conductorone/baton-sdk/pkg/dotc1z"
	"github.com/conductorone/baton-sdk/pkg/dotc1z/c1zstore"
	"github.com/conductorone/baton-sdk/pkg/logging"
)

func sanitizeCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "sanitize",
		Short: "Write an identity-stripped copy of a c1z whose graph topology and cardinalities are preserved",
		RunE:  runSanitize,
	}

	cmd.Flags().String("out", "", "Path to the sanitized .c1z output file (required)")
	cmd.Flags().String("secret-file", "", "Path to a per-c1z HMAC secret (>=32 random bytes). If unset, a fresh secret is generated and written next to --out.")
	cmd.Flags().String("anchor", "", "RFC3339 timestamp the newest source timestamp lands on. Defaults to now.")
	cmd.Flags().Bool("allow-unknown-annotations", false, "Pass annotations of unknown type through unchanged instead of dropping. Dangerous on real customer data.")
	cmd.Flags().String("tmp-dir", "", "The temporary directory to use while sanitizing")

	return cmd
}

func runSanitize(cmd *cobra.Command, args []string) (retErr error) {
	signalCtx, stop := signal.NotifyContext(cmd.Context(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	ctx, err := logging.Init(signalCtx, logging.WithLogFormat("console"), logging.WithLogLevel("info"))
	if err != nil {
		return fmt.Errorf("init logging: %w", err)
	}
	log := ctxzap.Extract(ctx)

	inPath, err := cmd.Flags().GetString("file")
	if err != nil {
		return err
	}
	outPath, err := cmd.Flags().GetString("out")
	if err != nil {
		return err
	}
	secretFile, err := cmd.Flags().GetString("secret-file")
	if err != nil {
		return err
	}
	anchorRaw, err := cmd.Flags().GetString("anchor")
	if err != nil {
		return err
	}
	allowUnknown, err := cmd.Flags().GetBool("allow-unknown-annotations")
	if err != nil {
		return err
	}
	tmpDir, err := cmd.Flags().GetString("tmp-dir")
	if err != nil {
		return err
	}
	if outPath == "" {
		return fmt.Errorf("--out is required")
	}
	// All input validation happens BEFORE the secret is loaded or
	// generated: generating first would leave a stray .secret file
	// next to --out on every failed invocation.
	var anchor time.Time
	if anchorRaw != "" {
		anchor, err = time.Parse(time.RFC3339, anchorRaw)
		if err != nil {
			return fmt.Errorf("parse --anchor: %w", err)
		}
	}
	if _, err := os.Stat(inPath); err != nil {
		return fmt.Errorf("stat --file: %w", err)
	}
	if _, err := os.Stat(outPath); err == nil {
		probe, err := dotc1z.NewStore(ctx, outPath, dotc1z.WithReadOnly(true))
		if err != nil {
			return fmt.Errorf("open existing --out: %w", err)
		}
		engine := probe.Metadata().Engine
		closeErr := probe.Close(ctx)
		if closeErr != nil {
			return fmt.Errorf("close existing --out probe: %w", closeErr)
		}
		if engine != string(c1zstore.EnginePebble) {
			return fmt.Errorf("existing --out must use the Pebble engine, got %q", engine)
		}
	}

	secret, generated, err := c1zsanitize.LoadOrGenerateSecret(secretFile, outPath)
	if err != nil {
		return err
	}
	if generated {
		log.Warn("c1zsanitize: generated fresh secret; archive it if you want reversibility",
			zap.String("path", c1zsanitize.SecretPath(secretFile, outPath)))
	}

	var srcOpts []dotc1z.C1ZOption
	if tmpDir != "" {
		srcOpts = append(srcOpts, dotc1z.WithTmpDir(tmpDir))
	}
	src, err := openReadOnlyC1ZStore(ctx, inPath, srcOpts...)
	if err != nil {
		return fmt.Errorf("open source c1z: %w", err)
	}
	defer src.Close(ctx)

	dstOpts := []dotc1z.C1ZOption{dotc1z.WithEngine(c1zstore.EnginePebble)}
	if tmpDir != "" {
		dstOpts = append(dstOpts, dotc1z.WithTmpDir(tmpDir))
	}
	dst, err := dotc1z.NewStore(ctx, outPath, dstOpts...)
	if err != nil {
		return fmt.Errorf("open dst c1z: %w", err)
	}
	// Close publishes the output envelope. A signal during that save would
	// discard the run, so both close paths outlive ctx.
	closeDst := func() error {
		closeCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 10*time.Minute)
		defer cancel()
		return dst.Close(closeCtx)
	}
	dstClosed := false
	defer func() {
		if !dstClosed {
			retErr = errors.Join(retErr, closeDst())
		}
	}()

	opts := c1zsanitize.Options{
		Secret:                  secret,
		TimestampAnchor:         anchor,
		AllowUnknownAnnotations: allowUnknown,
	}

	log.Info("c1zsanitize: starting",
		zap.String("in", inPath),
		zap.String("out", outPath),
		zap.Bool("drop_unknown_annotations", !opts.AllowUnknownAnnotations),
	)
	start := time.Now()
	if err := c1zsanitize.Sanitize(ctx, src, dst, opts); err != nil {
		return fmt.Errorf("sanitize: %w", err)
	}
	dstClosed = true
	if err := closeDst(); err != nil {
		return fmt.Errorf("failed to finalize output c1z: %w", err)
	}
	log.Info("c1zsanitize: done", zap.Duration("elapsed", time.Since(start)))
	return nil
}
